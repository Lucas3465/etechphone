﻿namespace Diseño
{
    partial class Principal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelD = new System.Windows.Forms.Panel();
            this.btnRecargar = new System.Windows.Forms.PictureBox();
            this.btnMenuPrincipal = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnModificar = new System.Windows.Forms.Button();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.btnCerrarSesion = new System.Windows.Forms.Button();
            this.label_Filtrar = new System.Windows.Forms.Label();
            this.MenuOpcionesCelular = new System.Windows.Forms.ComboBox();
            this.txtCampo_Busqueda = new System.Windows.Forms.TextBox();
            this.panelE = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox_Taller = new System.Windows.Forms.PictureBox();
            this.label_Name_Form = new System.Windows.Forms.Label();
            this.btnMenu = new System.Windows.Forms.Button();
            this.panel_Agregar = new System.Windows.Forms.Panel();
            this.groupBox_AgregarCelulares = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_BuscarClientesEnElComboboxDeAgregarCelulares = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dateTimePicker_FechaPlazo_Agregar = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label_CaracteresRestantes_Detalles_Agregar = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDetallesUobservaciones_Agregar = new System.Windows.Forms.TextBox();
            this.radioButton_Arreglado_Agregar = new System.Windows.Forms.RadioButton();
            this.radioButton_EnProceso_Agregar = new System.Windows.Forms.RadioButton();
            this.radioButton_EnEspera_Agregar = new System.Windows.Forms.RadioButton();
            this.radioButton_Averiado_Agregar = new System.Windows.Forms.RadioButton();
            this.comboBox_AgregarCelular_CedulaDelDueño = new System.Windows.Forms.ComboBox();
            this.comboBox_AgregarCelular_IdDelTecnicoAcargo = new System.Windows.Forms.ComboBox();
            this.dateTimePicker_FechaDeIngreso_Agregar = new System.Windows.Forms.DateTimePicker();
            this.btnAgregar_Celular = new System.Windows.Forms.Button();
            this.labelAdelanto_Agregar = new System.Windows.Forms.Label();
            this.txtAdelanto_Agregar = new System.Windows.Forms.TextBox();
            this.labelTecnico_A_Cargo_Agregar = new System.Windows.Forms.Label();
            this.labelFechaDeIngreso_Agregar = new System.Windows.Forms.Label();
            this.labelPresupuesto_Agregar = new System.Windows.Forms.Label();
            this.txtPresupuesto_Agregar = new System.Windows.Forms.TextBox();
            this.txtModeloYOmarca_Agregar = new System.Windows.Forms.TextBox();
            this.labelModelo_Agregar = new System.Windows.Forms.Label();
            this.txtIMEI_Agregar = new System.Windows.Forms.TextBox();
            this.labelIMEI_Agregar = new System.Windows.Forms.Label();
            this.labelID_Dueño_Agregar = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.timer_Agregar_Agrandar = new System.Windows.Forms.Timer(this.components);
            this.timer_GroupBox_AgregarC_Agrandar = new System.Windows.Forms.Timer(this.components);
            this.timer_Agregar_Reducir = new System.Windows.Forms.Timer(this.components);
            this.timer_GroupBox_AgregarC_Reducir = new System.Windows.Forms.Timer(this.components);
            this.timer_GroupBox_AgregarT_Agrandar = new System.Windows.Forms.Timer(this.components);
            this.timer_GroupBox_AgregarT_Reducir = new System.Windows.Forms.Timer(this.components);
            this.panel_Menu = new System.Windows.Forms.Panel();
            this.pictureBox_EtechLogo_PanelMenu = new System.Windows.Forms.PictureBox();
            this.groupBox_Menu = new System.Windows.Forms.GroupBox();
            this.btnClientes = new System.Windows.Forms.Button();
            this.btnEstadisticas = new System.Windows.Forms.Button();
            this.btnUsuarios = new System.Windows.Forms.Button();
            this.timer_Menu_Agrandar = new System.Windows.Forms.Timer(this.components);
            this.timer_Menu_Reducir = new System.Windows.Forms.Timer(this.components);
            this.timer_GroupBox_Menu_Agrandar = new System.Windows.Forms.Timer(this.components);
            this.timer_GroupBox_Menu_Reducir = new System.Windows.Forms.Timer(this.components);
            this.timer_GroupBox_ModificarC_Reducir = new System.Windows.Forms.Timer(this.components);
            this.timer_GroupBox_ModificarC_Agrandar = new System.Windows.Forms.Timer(this.components);
            this.panel_Modificar = new System.Windows.Forms.Panel();
            this.groupBox_ModificarTrabajos = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.combobox_IDCelular_Modificar_Trabajo = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.combobox_IDTecnico_Modificar_Trabajo = new System.Windows.Forms.ComboBox();
            this.labelID_Tecnico_Trabajo_Modificar = new System.Windows.Forms.Label();
            this.dateTimePicker_FechaDeIngreso_Modificar = new System.Windows.Forms.DateTimePicker();
            this.btnModificar_Trabajo = new System.Windows.Forms.Button();
            this.dateTimePicker_Plazo_Modificar = new System.Windows.Forms.DateTimePicker();
            this.txtAdelanto_Modificar = new System.Windows.Forms.TextBox();
            this.labelAdelanto_Modificar = new System.Windows.Forms.Label();
            this.labelFechaDeIngreso_Modificar = new System.Windows.Forms.Label();
            this.txtProblema_Modificar = new System.Windows.Forms.TextBox();
            this.labelProblema_Modificar = new System.Windows.Forms.Label();
            this.txtPresupuesto_Modificar = new System.Windows.Forms.TextBox();
            this.labelPresupuesto_Modificar = new System.Windows.Forms.Label();
            this.labelSeleccion_ID_Modificar = new System.Windows.Forms.Label();
            this.groupBox_ModificarCelulares = new System.Windows.Forms.GroupBox();
            this.groupBox_ModificarCelular_Estados = new System.Windows.Forms.GroupBox();
            this.label_caracteresRestantes_Detalles_Modificar = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDetallesUobservaciones_Modificar = new System.Windows.Forms.TextBox();
            this.radioButton_Arreglado_Modificar = new System.Windows.Forms.RadioButton();
            this.radioButton_EnProceso_Modificar = new System.Windows.Forms.RadioButton();
            this.radioButton_EnEspera_Modificar = new System.Windows.Forms.RadioButton();
            this.radioButton_Averiado_Modificar = new System.Windows.Forms.RadioButton();
            this.label20 = new System.Windows.Forms.Label();
            this.txt_PresupuestoModificar = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.dtp_ModificarCelular_Plazo = new System.Windows.Forms.DateTimePicker();
            this.label25 = new System.Windows.Forms.Label();
            this.txt_AdelantoModificar = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.comboBox_ModificarTecnicoACargo = new System.Windows.Forms.ComboBox();
            this.txtIMEI_Modificar = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.btn_ModificarTecnicoACargo_Buscar = new System.Windows.Forms.Button();
            this.btn_ModificarClientes_Buscar = new System.Windows.Forms.Button();
            this.dtp_ModificarIngresoCelulares = new System.Windows.Forms.DateTimePicker();
            this.combobox_CI_Del_Dueño_Modificar = new System.Windows.Forms.ComboBox();
            this.label_modificarCelular_Seleccion = new System.Windows.Forms.Label();
            this.btnModificar_Celular = new System.Windows.Forms.Button();
            this.labelID_Dueño_Modificar = new System.Windows.Forms.Label();
            this.labelTecnico_A_Cargo_Modificar = new System.Windows.Forms.Label();
            this.labelIMEI_Modificar = new System.Windows.Forms.Label();
            this.txtModelo_Modificar = new System.Windows.Forms.TextBox();
            this.labelMarca_Modificar = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.timer_GroupBox_ModificarT_Agrandar = new System.Windows.Forms.Timer(this.components);
            this.timer_GroupBox_ModificarT_Reducir = new System.Windows.Forms.Timer(this.components);
            this.timer_Modificar_Agrandar = new System.Windows.Forms.Timer(this.components);
            this.timer_Modificar_Reducir = new System.Windows.Forms.Timer(this.components);
            this.panel_Eliminar = new System.Windows.Forms.Panel();
            this.groupBox_EliminarTrabajos = new System.Windows.Forms.GroupBox();
            this.txtID_Trabajo_Eliminar = new System.Windows.Forms.Label();
            this.btn_EliminarTrabajos = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox_EliminarCelulares = new System.Windows.Forms.GroupBox();
            this.labMostrarIDdelCelularSeleccionado = new System.Windows.Forms.Label();
            this.btnEliminar_Celular = new System.Windows.Forms.Button();
            this.label_ID_Celular_Eliminar = new System.Windows.Forms.Label();
            this.timer_GroupBox_EliminarC_Agrandar = new System.Windows.Forms.Timer(this.components);
            this.timer_GroupBox_EliminarC_Reducir = new System.Windows.Forms.Timer(this.components);
            this.timer_GroupBox_EliminarT_Reducir = new System.Windows.Forms.Timer(this.components);
            this.timer_GroupBox_EliminarT_Agrandar = new System.Windows.Forms.Timer(this.components);
            this.timer_Eliminar_Agrandar = new System.Windows.Forms.Timer(this.components);
            this.timer_Eliminar_Reducir = new System.Windows.Forms.Timer(this.components);
            this.tablaCelulares = new System.Windows.Forms.DataGridView();
            this.tabIndex_Pestañas = new System.Windows.Forms.TabControl();
            this.tab_Celulares = new System.Windows.Forms.TabPage();
            this.timer_RecargarBDs = new System.Windows.Forms.Timer(this.components);
            this.timer_Transicion = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelD.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnRecargar)).BeginInit();
            this.panelE.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Taller)).BeginInit();
            this.panel_Agregar.SuspendLayout();
            this.groupBox_AgregarCelulares.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel_Menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_EtechLogo_PanelMenu)).BeginInit();
            this.groupBox_Menu.SuspendLayout();
            this.panel_Modificar.SuspendLayout();
            this.groupBox_ModificarTrabajos.SuspendLayout();
            this.groupBox_ModificarCelulares.SuspendLayout();
            this.groupBox_ModificarCelular_Estados.SuspendLayout();
            this.panel_Eliminar.SuspendLayout();
            this.groupBox_EliminarTrabajos.SuspendLayout();
            this.groupBox_EliminarCelulares.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tablaCelulares)).BeginInit();
            this.tabIndex_Pestañas.SuspendLayout();
            this.tab_Celulares.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelD
            // 
            this.panelD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panelD.Controls.Add(this.btnRecargar);
            this.panelD.Controls.Add(this.btnMenuPrincipal);
            this.panelD.Controls.Add(this.btnEliminar);
            this.panelD.Controls.Add(this.btnModificar);
            this.panelD.Controls.Add(this.btnAgregar);
            this.panelD.Controls.Add(this.btnCerrarSesion);
            this.panelD.Location = new System.Drawing.Point(0, 25);
            this.panelD.Name = "panelD";
            this.panelD.Size = new System.Drawing.Size(45, 1060);
            this.panelD.TabIndex = 5;
            // 
            // btnRecargar
            // 
            this.btnRecargar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRecargar.Image = ((System.Drawing.Image)(resources.GetObject("btnRecargar.Image")));
            this.btnRecargar.Location = new System.Drawing.Point(10, 285);
            this.btnRecargar.Name = "btnRecargar";
            this.btnRecargar.Size = new System.Drawing.Size(25, 25);
            this.btnRecargar.TabIndex = 21;
            this.btnRecargar.TabStop = false;
            this.btnRecargar.Click += new System.EventHandler(this.btnRecargar_Click);
            // 
            // btnMenuPrincipal
            // 
            this.btnMenuPrincipal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.btnMenuPrincipal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMenuPrincipal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuPrincipal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuPrincipal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.btnMenuPrincipal.Image = global::Diseño.Properties.Resources.menu;
            this.btnMenuPrincipal.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuPrincipal.Location = new System.Drawing.Point(0, 230);
            this.btnMenuPrincipal.Name = "btnMenuPrincipal";
            this.btnMenuPrincipal.Size = new System.Drawing.Size(120, 46);
            this.btnMenuPrincipal.TabIndex = 16;
            this.btnMenuPrincipal.Text = "Menu";
            this.btnMenuPrincipal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMenuPrincipal.UseVisualStyleBackColor = false;
            this.btnMenuPrincipal.Click += new System.EventHandler(this.btnMenu_Principal);
            // 
            // btnEliminar
            // 
            this.btnEliminar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.btnEliminar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.btnEliminar.Image = ((System.Drawing.Image)(resources.GetObject("btnEliminar.Image")));
            this.btnEliminar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEliminar.Location = new System.Drawing.Point(0, 184);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(120, 46);
            this.btnEliminar.TabIndex = 14;
            this.btnEliminar.Text = "Quitar";
            this.btnEliminar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEliminar.UseVisualStyleBackColor = false;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // btnModificar
            // 
            this.btnModificar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.btnModificar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.btnModificar.Image = ((System.Drawing.Image)(resources.GetObject("btnModificar.Image")));
            this.btnModificar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModificar.Location = new System.Drawing.Point(0, 132);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(120, 46);
            this.btnModificar.TabIndex = 14;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModificar.UseVisualStyleBackColor = false;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // btnAgregar
            // 
            this.btnAgregar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.btnAgregar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.btnAgregar.Image = ((System.Drawing.Image)(resources.GetObject("btnAgregar.Image")));
            this.btnAgregar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAgregar.Location = new System.Drawing.Point(0, 80);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnAgregar.Size = new System.Drawing.Size(120, 46);
            this.btnAgregar.TabIndex = 1;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAgregar.UseVisualStyleBackColor = false;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // btnCerrarSesion
            // 
            this.btnCerrarSesion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCerrarSesion.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCerrarSesion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrarSesion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCerrarSesion.ForeColor = System.Drawing.Color.Firebrick;
            this.btnCerrarSesion.Image = ((System.Drawing.Image)(resources.GetObject("btnCerrarSesion.Image")));
            this.btnCerrarSesion.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCerrarSesion.Location = new System.Drawing.Point(0, 638);
            this.btnCerrarSesion.Name = "btnCerrarSesion";
            this.btnCerrarSesion.Size = new System.Drawing.Size(120, 46);
            this.btnCerrarSesion.TabIndex = 3;
            this.btnCerrarSesion.Text = "Salir";
            this.btnCerrarSesion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCerrarSesion.UseVisualStyleBackColor = true;
            this.btnCerrarSesion.Click += new System.EventHandler(this.btnCerrarSesion_Click);
            // 
            // label_Filtrar
            // 
            this.label_Filtrar.AutoSize = true;
            this.label_Filtrar.BackColor = System.Drawing.Color.Transparent;
            this.label_Filtrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Filtrar.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label_Filtrar.Location = new System.Drawing.Point(486, 35);
            this.label_Filtrar.Name = "label_Filtrar";
            this.label_Filtrar.Size = new System.Drawing.Size(62, 15);
            this.label_Filtrar.TabIndex = 6;
            this.label_Filtrar.Text = "Filtrar por:";
            // 
            // MenuOpcionesCelular
            // 
            this.MenuOpcionesCelular.BackColor = System.Drawing.Color.White;
            this.MenuOpcionesCelular.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MenuOpcionesCelular.Enabled = false;
            this.MenuOpcionesCelular.Items.AddRange(new object[] {
            "Cedula del Propietario",
            "Estado",
            "Ingreso",
            "Modelo y/o Marca",
            "Plazo",
            "Tecnico a cargo"});
            this.MenuOpcionesCelular.Location = new System.Drawing.Point(556, 33);
            this.MenuOpcionesCelular.Name = "MenuOpcionesCelular";
            this.MenuOpcionesCelular.Size = new System.Drawing.Size(121, 21);
            this.MenuOpcionesCelular.Sorted = true;
            this.MenuOpcionesCelular.TabIndex = 7;
            this.MenuOpcionesCelular.Visible = false;
            this.MenuOpcionesCelular.SelectedIndexChanged += new System.EventHandler(this.MenuOpciones_SelectedIndexChanged);
            // 
            // txtCampo_Busqueda
            // 
            this.txtCampo_Busqueda.Enabled = false;
            this.txtCampo_Busqueda.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCampo_Busqueda.Location = new System.Drawing.Point(683, 33);
            this.txtCampo_Busqueda.Name = "txtCampo_Busqueda";
            this.txtCampo_Busqueda.Size = new System.Drawing.Size(323, 22);
            this.txtCampo_Busqueda.TabIndex = 8;
            this.txtCampo_Busqueda.TextChanged += new System.EventHandler(this.txtCampo_Busqueda_TextChanged);
            // 
            // panelE
            // 
            this.panelE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.panelE.Controls.Add(this.label1);
            this.panelE.Controls.Add(this.pictureBox_Taller);
            this.panelE.Controls.Add(this.label_Name_Form);
            this.panelE.Controls.Add(this.btnMenu);
            this.panelE.Controls.Add(this.label_Filtrar);
            this.panelE.Controls.Add(this.MenuOpcionesCelular);
            this.panelE.Controls.Add(this.txtCampo_Busqueda);
            this.panelE.Location = new System.Drawing.Point(0, 25);
            this.panelE.Name = "panelE";
            this.panelE.Size = new System.Drawing.Size(2000, 74);
            this.panelE.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(680, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 15);
            this.label1.TabIndex = 25;
            this.label1.Text = "Búsqueda";
            // 
            // pictureBox_Taller
            // 
            this.pictureBox_Taller.Image = global::Diseño.Properties.Resources.telefono_inteligente__1_;
            this.pictureBox_Taller.Location = new System.Drawing.Point(129, 9);
            this.pictureBox_Taller.Name = "pictureBox_Taller";
            this.pictureBox_Taller.Size = new System.Drawing.Size(59, 58);
            this.pictureBox_Taller.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Taller.TabIndex = 21;
            this.pictureBox_Taller.TabStop = false;
            // 
            // label_Name_Form
            // 
            this.label_Name_Form.AutoSize = true;
            this.label_Name_Form.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.label_Name_Form.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Name_Form.Font = new System.Drawing.Font("Montserrat", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Name_Form.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label_Name_Form.Location = new System.Drawing.Point(196, 22);
            this.label_Name_Form.Name = "label_Name_Form";
            this.label_Name_Form.Size = new System.Drawing.Size(124, 37);
            this.label_Name_Form.TabIndex = 14;
            this.label_Name_Form.Text = "TALLER";
            // 
            // btnMenu
            // 
            this.btnMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnMenu.Image = global::Diseño.Properties.Resources.contexto__1_;
            this.btnMenu.Location = new System.Drawing.Point(0, 18);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(45, 41);
            this.btnMenu.TabIndex = 11;
            this.btnMenu.UseVisualStyleBackColor = true;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // panel_Agregar
            // 
            this.panel_Agregar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel_Agregar.Controls.Add(this.groupBox_AgregarCelulares);
            this.panel_Agregar.Enabled = false;
            this.panel_Agregar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel_Agregar.Location = new System.Drawing.Point(51, 105);
            this.panel_Agregar.Name = "panel_Agregar";
            this.panel_Agregar.Size = new System.Drawing.Size(419, 600);
            this.panel_Agregar.TabIndex = 15;
            // 
            // groupBox_AgregarCelulares
            // 
            this.groupBox_AgregarCelulares.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox_AgregarCelulares.Controls.Add(this.button1);
            this.groupBox_AgregarCelulares.Controls.Add(this.btn_BuscarClientesEnElComboboxDeAgregarCelulares);
            this.groupBox_AgregarCelulares.Controls.Add(this.label14);
            this.groupBox_AgregarCelulares.Controls.Add(this.label13);
            this.groupBox_AgregarCelulares.Controls.Add(this.label10);
            this.groupBox_AgregarCelulares.Controls.Add(this.label8);
            this.groupBox_AgregarCelulares.Controls.Add(this.dateTimePicker_FechaPlazo_Agregar);
            this.groupBox_AgregarCelulares.Controls.Add(this.label7);
            this.groupBox_AgregarCelulares.Controls.Add(this.groupBox1);
            this.groupBox_AgregarCelulares.Controls.Add(this.comboBox_AgregarCelular_CedulaDelDueño);
            this.groupBox_AgregarCelulares.Controls.Add(this.comboBox_AgregarCelular_IdDelTecnicoAcargo);
            this.groupBox_AgregarCelulares.Controls.Add(this.dateTimePicker_FechaDeIngreso_Agregar);
            this.groupBox_AgregarCelulares.Controls.Add(this.btnAgregar_Celular);
            this.groupBox_AgregarCelulares.Controls.Add(this.labelAdelanto_Agregar);
            this.groupBox_AgregarCelulares.Controls.Add(this.txtAdelanto_Agregar);
            this.groupBox_AgregarCelulares.Controls.Add(this.labelTecnico_A_Cargo_Agregar);
            this.groupBox_AgregarCelulares.Controls.Add(this.labelFechaDeIngreso_Agregar);
            this.groupBox_AgregarCelulares.Controls.Add(this.labelPresupuesto_Agregar);
            this.groupBox_AgregarCelulares.Controls.Add(this.txtPresupuesto_Agregar);
            this.groupBox_AgregarCelulares.Controls.Add(this.txtModeloYOmarca_Agregar);
            this.groupBox_AgregarCelulares.Controls.Add(this.labelModelo_Agregar);
            this.groupBox_AgregarCelulares.Controls.Add(this.txtIMEI_Agregar);
            this.groupBox_AgregarCelulares.Controls.Add(this.labelIMEI_Agregar);
            this.groupBox_AgregarCelulares.Controls.Add(this.labelID_Dueño_Agregar);
            this.groupBox_AgregarCelulares.Controls.Add(this.label11);
            this.groupBox_AgregarCelulares.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_AgregarCelulares.Location = new System.Drawing.Point(3, 3);
            this.groupBox_AgregarCelulares.Name = "groupBox_AgregarCelulares";
            this.groupBox_AgregarCelulares.Size = new System.Drawing.Size(413, 594);
            this.groupBox_AgregarCelulares.TabIndex = 0;
            this.groupBox_AgregarCelulares.TabStop = false;
            this.groupBox_AgregarCelulares.Text = "Agregar Celular";
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button1.Image = global::Diseño.Properties.Resources.lupa2;
            this.button1.Location = new System.Drawing.Point(191, 306);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(26, 24);
            this.button1.TabIndex = 48;
            this.button1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btn_BuscarClientesEnElComboboxDeAgregarCelulares
            // 
            this.btn_BuscarClientesEnElComboboxDeAgregarCelulares.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_BuscarClientesEnElComboboxDeAgregarCelulares.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_BuscarClientesEnElComboboxDeAgregarCelulares.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_BuscarClientesEnElComboboxDeAgregarCelulares.Image = global::Diseño.Properties.Resources.lupa2;
            this.btn_BuscarClientesEnElComboboxDeAgregarCelulares.Location = new System.Drawing.Point(192, 36);
            this.btn_BuscarClientesEnElComboboxDeAgregarCelulares.Name = "btn_BuscarClientesEnElComboboxDeAgregarCelulares";
            this.btn_BuscarClientesEnElComboboxDeAgregarCelulares.Size = new System.Drawing.Size(26, 24);
            this.btn_BuscarClientesEnElComboboxDeAgregarCelulares.TabIndex = 47;
            this.btn_BuscarClientesEnElComboboxDeAgregarCelulares.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btn_BuscarClientesEnElComboboxDeAgregarCelulares.UseVisualStyleBackColor = true;
            this.btn_BuscarClientesEnElComboboxDeAgregarCelulares.Click += new System.EventHandler(this.button1_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(160, 178);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(15, 18);
            this.label14.TabIndex = 46;
            this.label14.Text = "*";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(147, 95);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(15, 18);
            this.label13.TabIndex = 45;
            this.label13.Text = "*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(94, 57);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(15, 18);
            this.label10.TabIndex = 42;
            this.label10.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(113, 17);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(15, 18);
            this.label8.TabIndex = 40;
            this.label8.Text = "*";
            // 
            // dateTimePicker_FechaPlazo_Agregar
            // 
            this.dateTimePicker_FechaPlazo_Agregar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dateTimePicker_FechaPlazo_Agregar.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker_FechaPlazo_Agregar.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_FechaPlazo_Agregar.Location = new System.Drawing.Point(5, 193);
            this.dateTimePicker_FechaPlazo_Agregar.Name = "dateTimePicker_FechaPlazo_Agregar";
            this.dateTimePicker_FechaPlazo_Agregar.Size = new System.Drawing.Size(161, 20);
            this.dateTimePicker_FechaPlazo_Agregar.TabIndex = 20;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(4, 179);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(161, 13);
            this.label7.TabIndex = 38;
            this.label7.Text = "Plazo para arreglar el dispositivo:";
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSize = true;
            this.groupBox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label_CaracteresRestantes_Detalles_Agregar);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtDetallesUobservaciones_Agregar);
            this.groupBox1.Controls.Add(this.radioButton_Arreglado_Agregar);
            this.groupBox1.Controls.Add(this.radioButton_EnProceso_Agregar);
            this.groupBox1.Controls.Add(this.radioButton_EnEspera_Agregar);
            this.groupBox1.Controls.Add(this.radioButton_Averiado_Agregar);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Location = new System.Drawing.Point(4, 360);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(395, 182);
            this.groupBox1.TabIndex = 37;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Estado en el que está el dispositivo (Actualmente)";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(277, 77);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(15, 18);
            this.label16.TabIndex = 48;
            this.label16.Text = "*";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(242, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(15, 18);
            this.label15.TabIndex = 47;
            this.label15.Text = "*";
            // 
            // label_CaracteresRestantes_Detalles_Agregar
            // 
            this.label_CaracteresRestantes_Detalles_Agregar.AutoSize = true;
            this.label_CaracteresRestantes_Detalles_Agregar.Location = new System.Drawing.Point(315, 79);
            this.label_CaracteresRestantes_Detalles_Agregar.Name = "label_CaracteresRestantes_Detalles_Agregar";
            this.label_CaracteresRestantes_Detalles_Agregar.Size = new System.Drawing.Size(72, 13);
            this.label_CaracteresRestantes_Detalles_Agregar.TabIndex = 38;
            this.label_CaracteresRestantes_Detalles_Agregar.Text = "65535/65535";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(276, 13);
            this.label3.TabIndex = 37;
            this.label3.Text = "Observaciones hechas acerca del estado del dispositivo:";
            // 
            // txtDetallesUobservaciones_Agregar
            // 
            this.txtDetallesUobservaciones_Agregar.Location = new System.Drawing.Point(7, 97);
            this.txtDetallesUobservaciones_Agregar.MaxLength = 0;
            this.txtDetallesUobservaciones_Agregar.Multiline = true;
            this.txtDetallesUobservaciones_Agregar.Name = "txtDetallesUobservaciones_Agregar";
            this.txtDetallesUobservaciones_Agregar.Size = new System.Drawing.Size(382, 66);
            this.txtDetallesUobservaciones_Agregar.TabIndex = 24;
            this.txtDetallesUobservaciones_Agregar.TextChanged += new System.EventHandler(this.txtDetallesUobservaciones_Agregar_TextChanged);
            this.txtDetallesUobservaciones_Agregar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDetallesUobservaciones_Agregar_KeyPress);
            this.txtDetallesUobservaciones_Agregar.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtDetallesUobservaciones_Agregar_KeyUp);
            // 
            // radioButton_Arreglado_Agregar
            // 
            this.radioButton_Arreglado_Agregar.AutoSize = true;
            this.radioButton_Arreglado_Agregar.BackColor = System.Drawing.Color.LightGreen;
            this.radioButton_Arreglado_Agregar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radioButton_Arreglado_Agregar.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_Arreglado_Agregar.ForeColor = System.Drawing.Color.Black;
            this.radioButton_Arreglado_Agregar.Location = new System.Drawing.Point(7, 20);
            this.radioButton_Arreglado_Agregar.Name = "radioButton_Arreglado_Agregar";
            this.radioButton_Arreglado_Agregar.Size = new System.Drawing.Size(80, 18);
            this.radioButton_Arreglado_Agregar.TabIndex = 27;
            this.radioButton_Arreglado_Agregar.TabStop = true;
            this.radioButton_Arreglado_Agregar.Text = "Arreglado";
            this.radioButton_Arreglado_Agregar.UseVisualStyleBackColor = false;
            // 
            // radioButton_EnProceso_Agregar
            // 
            this.radioButton_EnProceso_Agregar.AutoSize = true;
            this.radioButton_EnProceso_Agregar.BackColor = System.Drawing.Color.MidnightBlue;
            this.radioButton_EnProceso_Agregar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radioButton_EnProceso_Agregar.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_EnProceso_Agregar.ForeColor = System.Drawing.SystemColors.Control;
            this.radioButton_EnProceso_Agregar.Location = new System.Drawing.Point(6, 46);
            this.radioButton_EnProceso_Agregar.Name = "radioButton_EnProceso_Agregar";
            this.radioButton_EnProceso_Agregar.Size = new System.Drawing.Size(90, 18);
            this.radioButton_EnProceso_Agregar.TabIndex = 35;
            this.radioButton_EnProceso_Agregar.TabStop = true;
            this.radioButton_EnProceso_Agregar.Text = "En  proceso";
            this.radioButton_EnProceso_Agregar.UseVisualStyleBackColor = false;
            // 
            // radioButton_EnEspera_Agregar
            // 
            this.radioButton_EnEspera_Agregar.AutoSize = true;
            this.radioButton_EnEspera_Agregar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(221)))), ((int)(((byte)(51)))));
            this.radioButton_EnEspera_Agregar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radioButton_EnEspera_Agregar.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_EnEspera_Agregar.Location = new System.Drawing.Point(135, 48);
            this.radioButton_EnEspera_Agregar.Name = "radioButton_EnEspera_Agregar";
            this.radioButton_EnEspera_Agregar.Size = new System.Drawing.Size(80, 18);
            this.radioButton_EnEspera_Agregar.TabIndex = 34;
            this.radioButton_EnEspera_Agregar.TabStop = true;
            this.radioButton_EnEspera_Agregar.Text = "En espera";
            this.radioButton_EnEspera_Agregar.UseVisualStyleBackColor = false;
            // 
            // radioButton_Averiado_Agregar
            // 
            this.radioButton_Averiado_Agregar.AutoSize = true;
            this.radioButton_Averiado_Agregar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.radioButton_Averiado_Agregar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radioButton_Averiado_Agregar.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_Averiado_Agregar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.radioButton_Averiado_Agregar.Location = new System.Drawing.Point(135, 20);
            this.radioButton_Averiado_Agregar.Name = "radioButton_Averiado_Agregar";
            this.radioButton_Averiado_Agregar.Size = new System.Drawing.Size(74, 18);
            this.radioButton_Averiado_Agregar.TabIndex = 28;
            this.radioButton_Averiado_Agregar.TabStop = true;
            this.radioButton_Averiado_Agregar.Text = "Averiado";
            this.radioButton_Averiado_Agregar.UseVisualStyleBackColor = false;
            // 
            // comboBox_AgregarCelular_CedulaDelDueño
            // 
            this.comboBox_AgregarCelular_CedulaDelDueño.FormattingEnabled = true;
            this.comboBox_AgregarCelular_CedulaDelDueño.Location = new System.Drawing.Point(5, 36);
            this.comboBox_AgregarCelular_CedulaDelDueño.Name = "comboBox_AgregarCelular_CedulaDelDueño";
            this.comboBox_AgregarCelular_CedulaDelDueño.Size = new System.Drawing.Size(181, 21);
            this.comboBox_AgregarCelular_CedulaDelDueño.Sorted = true;
            this.comboBox_AgregarCelular_CedulaDelDueño.TabIndex = 16;
            this.comboBox_AgregarCelular_CedulaDelDueño.TextChanged += new System.EventHandler(this.comboBox_AgregarCelular_CedulaDelDueño_TextChanged);
            this.comboBox_AgregarCelular_CedulaDelDueño.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBox_AgregarCelular_CedulaDelDueño_KeyPress);
            // 
            // comboBox_AgregarCelular_IdDelTecnicoAcargo
            // 
            this.comboBox_AgregarCelular_IdDelTecnicoAcargo.FormattingEnabled = true;
            this.comboBox_AgregarCelular_IdDelTecnicoAcargo.Location = new System.Drawing.Point(5, 309);
            this.comboBox_AgregarCelular_IdDelTecnicoAcargo.Name = "comboBox_AgregarCelular_IdDelTecnicoAcargo";
            this.comboBox_AgregarCelular_IdDelTecnicoAcargo.Size = new System.Drawing.Size(180, 21);
            this.comboBox_AgregarCelular_IdDelTecnicoAcargo.Sorted = true;
            this.comboBox_AgregarCelular_IdDelTecnicoAcargo.TabIndex = 23;
            this.comboBox_AgregarCelular_IdDelTecnicoAcargo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBox_AgregarCelular_IdDelTecnicoAcargo_KeyPress);
            // 
            // dateTimePicker_FechaDeIngreso_Agregar
            // 
            this.dateTimePicker_FechaDeIngreso_Agregar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dateTimePicker_FechaDeIngreso_Agregar.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker_FechaDeIngreso_Agregar.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_FechaDeIngreso_Agregar.Location = new System.Drawing.Point(5, 113);
            this.dateTimePicker_FechaDeIngreso_Agregar.Name = "dateTimePicker_FechaDeIngreso_Agregar";
            this.dateTimePicker_FechaDeIngreso_Agregar.Size = new System.Drawing.Size(161, 20);
            this.dateTimePicker_FechaDeIngreso_Agregar.TabIndex = 18;
            // 
            // btnAgregar_Celular
            // 
            this.btnAgregar_Celular.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgregar_Celular.Location = new System.Drawing.Point(312, 555);
            this.btnAgregar_Celular.Name = "btnAgregar_Celular";
            this.btnAgregar_Celular.Size = new System.Drawing.Size(92, 30);
            this.btnAgregar_Celular.TabIndex = 25;
            this.btnAgregar_Celular.Text = "Agregar";
            this.btnAgregar_Celular.UseVisualStyleBackColor = true;
            this.btnAgregar_Celular.Click += new System.EventHandler(this.btnAgregarCelular_Click);
            // 
            // labelAdelanto_Agregar
            // 
            this.labelAdelanto_Agregar.AutoSize = true;
            this.labelAdelanto_Agregar.Location = new System.Drawing.Point(3, 137);
            this.labelAdelanto_Agregar.Name = "labelAdelanto_Agregar";
            this.labelAdelanto_Agregar.Size = new System.Drawing.Size(133, 13);
            this.labelAdelanto_Agregar.TabIndex = 10;
            this.labelAdelanto_Agregar.Text = "Adelanto/Seña (Opcional):";
            // 
            // txtAdelanto_Agregar
            // 
            this.txtAdelanto_Agregar.ForeColor = System.Drawing.Color.Green;
            this.txtAdelanto_Agregar.Location = new System.Drawing.Point(6, 153);
            this.txtAdelanto_Agregar.Name = "txtAdelanto_Agregar";
            this.txtAdelanto_Agregar.Size = new System.Drawing.Size(401, 20);
            this.txtAdelanto_Agregar.TabIndex = 19;
            this.txtAdelanto_Agregar.Text = "$";
            this.txtAdelanto_Agregar.TextChanged += new System.EventHandler(this.txtAdelanto_Agregar_TextChanged);
            // 
            // labelTecnico_A_Cargo_Agregar
            // 
            this.labelTecnico_A_Cargo_Agregar.AutoSize = true;
            this.labelTecnico_A_Cargo_Agregar.Location = new System.Drawing.Point(3, 293);
            this.labelTecnico_A_Cargo_Agregar.Name = "labelTecnico_A_Cargo_Agregar";
            this.labelTecnico_A_Cargo_Agregar.Size = new System.Drawing.Size(88, 13);
            this.labelTecnico_A_Cargo_Agregar.TabIndex = 9;
            this.labelTecnico_A_Cargo_Agregar.Text = "Tecnico a cargo:";
            // 
            // labelFechaDeIngreso_Agregar
            // 
            this.labelFechaDeIngreso_Agregar.AutoSize = true;
            this.labelFechaDeIngreso_Agregar.Location = new System.Drawing.Point(1, 97);
            this.labelFechaDeIngreso_Agregar.Name = "labelFechaDeIngreso_Agregar";
            this.labelFechaDeIngreso_Agregar.Size = new System.Drawing.Size(147, 13);
            this.labelFechaDeIngreso_Agregar.TabIndex = 8;
            this.labelFechaDeIngreso_Agregar.Text = "Cuando ingresó el dispositivo:";
            // 
            // labelPresupuesto_Agregar
            // 
            this.labelPresupuesto_Agregar.AutoSize = true;
            this.labelPresupuesto_Agregar.Location = new System.Drawing.Point(4, 216);
            this.labelPresupuesto_Agregar.Name = "labelPresupuesto_Agregar";
            this.labelPresupuesto_Agregar.Size = new System.Drawing.Size(120, 13);
            this.labelPresupuesto_Agregar.TabIndex = 4;
            this.labelPresupuesto_Agregar.Text = "Presupuesto (Opcional):";
            // 
            // txtPresupuesto_Agregar
            // 
            this.txtPresupuesto_Agregar.BackColor = System.Drawing.SystemColors.Window;
            this.txtPresupuesto_Agregar.ForeColor = System.Drawing.Color.Green;
            this.txtPresupuesto_Agregar.Location = new System.Drawing.Point(6, 232);
            this.txtPresupuesto_Agregar.Name = "txtPresupuesto_Agregar";
            this.txtPresupuesto_Agregar.Size = new System.Drawing.Size(400, 20);
            this.txtPresupuesto_Agregar.TabIndex = 21;
            this.txtPresupuesto_Agregar.Text = "$";
            this.txtPresupuesto_Agregar.TextChanged += new System.EventHandler(this.txtPresupuesto_Agregar_TextChanged);
            // 
            // txtModeloYOmarca_Agregar
            // 
            this.txtModeloYOmarca_Agregar.Location = new System.Drawing.Point(5, 75);
            this.txtModeloYOmarca_Agregar.Name = "txtModeloYOmarca_Agregar";
            this.txtModeloYOmarca_Agregar.Size = new System.Drawing.Size(402, 20);
            this.txtModeloYOmarca_Agregar.TabIndex = 17;
            // 
            // labelModelo_Agregar
            // 
            this.labelModelo_Agregar.AutoSize = true;
            this.labelModelo_Agregar.Location = new System.Drawing.Point(1, 60);
            this.labelModelo_Agregar.Name = "labelModelo_Agregar";
            this.labelModelo_Agregar.Size = new System.Drawing.Size(97, 13);
            this.labelModelo_Agregar.TabIndex = 4;
            this.labelModelo_Agregar.Text = "Modelo y/o Marca:";
            // 
            // txtIMEI_Agregar
            // 
            this.txtIMEI_Agregar.Location = new System.Drawing.Point(5, 270);
            this.txtIMEI_Agregar.Name = "txtIMEI_Agregar";
            this.txtIMEI_Agregar.Size = new System.Drawing.Size(402, 20);
            this.txtIMEI_Agregar.TabIndex = 22;
            // 
            // labelIMEI_Agregar
            // 
            this.labelIMEI_Agregar.AutoSize = true;
            this.labelIMEI_Agregar.Location = new System.Drawing.Point(3, 255);
            this.labelIMEI_Agregar.Name = "labelIMEI_Agregar";
            this.labelIMEI_Agregar.Size = new System.Drawing.Size(83, 13);
            this.labelIMEI_Agregar.TabIndex = 2;
            this.labelIMEI_Agregar.Text = "IMEI (Opcional):";
            // 
            // labelID_Dueño_Agregar
            // 
            this.labelID_Dueño_Agregar.AutoSize = true;
            this.labelID_Dueño_Agregar.Location = new System.Drawing.Point(2, 20);
            this.labelID_Dueño_Agregar.Name = "labelID_Dueño_Agregar";
            this.labelID_Dueño_Agregar.Size = new System.Drawing.Size(112, 13);
            this.labelID_Dueño_Agregar.TabIndex = 0;
            this.labelID_Dueño_Agregar.Text = "Propietario del Celular:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(97, 290);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(15, 18);
            this.label11.TabIndex = 43;
            this.label11.Text = "*";
            // 
            // timer_Agregar_Agrandar
            // 
            this.timer_Agregar_Agrandar.Interval = 20;
            this.timer_Agregar_Agrandar.Tick += new System.EventHandler(this.timer_Agregar_Agrandar_Tick);
            // 
            // timer_GroupBox_AgregarC_Agrandar
            // 
            this.timer_GroupBox_AgregarC_Agrandar.Interval = 1;
            this.timer_GroupBox_AgregarC_Agrandar.Tick += new System.EventHandler(this.timer_GroupBox_AgregarC_Agrandar_Tick);
            // 
            // timer_Agregar_Reducir
            // 
            this.timer_Agregar_Reducir.Interval = 1;
            this.timer_Agregar_Reducir.Tick += new System.EventHandler(this.timer_Agregar_Reducir_Tick);
            // 
            // timer_GroupBox_AgregarC_Reducir
            // 
            this.timer_GroupBox_AgregarC_Reducir.Interval = 1;
            this.timer_GroupBox_AgregarC_Reducir.Tick += new System.EventHandler(this.timer_GroupBox_AgregarC_Reducir_Tick);
            // 
            // timer_GroupBox_AgregarT_Agrandar
            // 
            this.timer_GroupBox_AgregarT_Agrandar.Interval = 1;
            this.timer_GroupBox_AgregarT_Agrandar.Tick += new System.EventHandler(this.timer_GroupBox_AgregarT_Agrandar_Tick);
            // 
            // timer_GroupBox_AgregarT_Reducir
            // 
            this.timer_GroupBox_AgregarT_Reducir.Interval = 1;
            this.timer_GroupBox_AgregarT_Reducir.Tick += new System.EventHandler(this.timer_GroupBox_AgregarT_Reducir_Tick);
            // 
            // panel_Menu
            // 
            this.panel_Menu.BackColor = System.Drawing.Color.White;
            this.panel_Menu.Controls.Add(this.pictureBox_EtechLogo_PanelMenu);
            this.panel_Menu.Controls.Add(this.groupBox_Menu);
            this.panel_Menu.Enabled = false;
            this.panel_Menu.Location = new System.Drawing.Point(51, 105);
            this.panel_Menu.Name = "panel_Menu";
            this.panel_Menu.Size = new System.Drawing.Size(419, 0);
            this.panel_Menu.TabIndex = 16;
            // 
            // pictureBox_EtechLogo_PanelMenu
            // 
            this.pictureBox_EtechLogo_PanelMenu.Image = global::Diseño.Properties.Resources.logo_etech_uruguay_220_e1654881097513_LARGE_Edited;
            this.pictureBox_EtechLogo_PanelMenu.Location = new System.Drawing.Point(122, 6);
            this.pictureBox_EtechLogo_PanelMenu.Name = "pictureBox_EtechLogo_PanelMenu";
            this.pictureBox_EtechLogo_PanelMenu.Size = new System.Drawing.Size(161, 71);
            this.pictureBox_EtechLogo_PanelMenu.TabIndex = 1;
            this.pictureBox_EtechLogo_PanelMenu.TabStop = false;
            // 
            // groupBox_Menu
            // 
            this.groupBox_Menu.BackColor = System.Drawing.Color.White;
            this.groupBox_Menu.Controls.Add(this.btnClientes);
            this.groupBox_Menu.Controls.Add(this.btnEstadisticas);
            this.groupBox_Menu.Controls.Add(this.btnUsuarios);
            this.groupBox_Menu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_Menu.Location = new System.Drawing.Point(3, 83);
            this.groupBox_Menu.Name = "groupBox_Menu";
            this.groupBox_Menu.Size = new System.Drawing.Size(413, 514);
            this.groupBox_Menu.TabIndex = 0;
            this.groupBox_Menu.TabStop = false;
            this.groupBox_Menu.Text = "Menú";
            // 
            // btnClientes
            // 
            this.btnClientes.BackColor = System.Drawing.Color.White;
            this.btnClientes.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClientes.Image = global::Diseño.Properties.Resources.cliente;
            this.btnClientes.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnClientes.Location = new System.Drawing.Point(4, 22);
            this.btnClientes.Name = "btnClientes";
            this.btnClientes.Size = new System.Drawing.Size(404, 91);
            this.btnClientes.TabIndex = 2;
            this.btnClientes.Text = "CLIENTES";
            this.btnClientes.UseVisualStyleBackColor = false;
            this.btnClientes.Click += new System.EventHandler(this.btnClientes_Click);
            // 
            // btnEstadisticas
            // 
            this.btnEstadisticas.BackColor = System.Drawing.Color.White;
            this.btnEstadisticas.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEstadisticas.Image = global::Diseño.Properties.Resources.vigilancia;
            this.btnEstadisticas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEstadisticas.Location = new System.Drawing.Point(3, 216);
            this.btnEstadisticas.Name = "btnEstadisticas";
            this.btnEstadisticas.Size = new System.Drawing.Size(404, 91);
            this.btnEstadisticas.TabIndex = 1;
            this.btnEstadisticas.Text = "ESTADISTICAS";
            this.btnEstadisticas.UseVisualStyleBackColor = false;
            this.btnEstadisticas.Click += new System.EventHandler(this.btnEstadisticas_Click);
            // 
            // btnUsuarios
            // 
            this.btnUsuarios.BackColor = System.Drawing.Color.White;
            this.btnUsuarios.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUsuarios.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUsuarios.Image = global::Diseño.Properties.Resources.work_from_home;
            this.btnUsuarios.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUsuarios.Location = new System.Drawing.Point(4, 119);
            this.btnUsuarios.Name = "btnUsuarios";
            this.btnUsuarios.Size = new System.Drawing.Size(404, 91);
            this.btnUsuarios.TabIndex = 0;
            this.btnUsuarios.Text = "USUARIOS";
            this.btnUsuarios.UseVisualStyleBackColor = false;
            this.btnUsuarios.Click += new System.EventHandler(this.btnUsuarios_Click);
            // 
            // timer_Menu_Agrandar
            // 
            this.timer_Menu_Agrandar.Interval = 1;
            this.timer_Menu_Agrandar.Tick += new System.EventHandler(this.timer_Menu_Agrandar_Tick);
            // 
            // timer_Menu_Reducir
            // 
            this.timer_Menu_Reducir.Interval = 1;
            this.timer_Menu_Reducir.Tick += new System.EventHandler(this.timer_Menu_Reducir_Tick);
            // 
            // timer_GroupBox_Menu_Agrandar
            // 
            this.timer_GroupBox_Menu_Agrandar.Interval = 1;
            this.timer_GroupBox_Menu_Agrandar.Tick += new System.EventHandler(this.timer_GroupBox_Menu_Agrandar_Tick);
            // 
            // timer_GroupBox_Menu_Reducir
            // 
            this.timer_GroupBox_Menu_Reducir.Interval = 1;
            this.timer_GroupBox_Menu_Reducir.Tick += new System.EventHandler(this.timer_GroupBox_Menu_Reducir_Tick);
            // 
            // timer_GroupBox_ModificarC_Reducir
            // 
            this.timer_GroupBox_ModificarC_Reducir.Interval = 1;
            this.timer_GroupBox_ModificarC_Reducir.Tick += new System.EventHandler(this.timer_GroupBox_ModificarC_Reducir_Tick);
            // 
            // timer_GroupBox_ModificarC_Agrandar
            // 
            this.timer_GroupBox_ModificarC_Agrandar.Interval = 1;
            this.timer_GroupBox_ModificarC_Agrandar.Tick += new System.EventHandler(this.timer_GroupBox_ModificarC_Agrandar_Tick);
            // 
            // panel_Modificar
            // 
            this.panel_Modificar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel_Modificar.Controls.Add(this.groupBox_ModificarTrabajos);
            this.panel_Modificar.Controls.Add(this.groupBox_ModificarCelulares);
            this.panel_Modificar.Enabled = false;
            this.panel_Modificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel_Modificar.Location = new System.Drawing.Point(51, 105);
            this.panel_Modificar.Name = "panel_Modificar";
            this.panel_Modificar.Size = new System.Drawing.Size(419, 0);
            this.panel_Modificar.TabIndex = 17;
            // 
            // groupBox_ModificarTrabajos
            // 
            this.groupBox_ModificarTrabajos.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox_ModificarTrabajos.Controls.Add(this.label6);
            this.groupBox_ModificarTrabajos.Controls.Add(this.combobox_IDCelular_Modificar_Trabajo);
            this.groupBox_ModificarTrabajos.Controls.Add(this.label4);
            this.groupBox_ModificarTrabajos.Controls.Add(this.combobox_IDTecnico_Modificar_Trabajo);
            this.groupBox_ModificarTrabajos.Controls.Add(this.labelID_Tecnico_Trabajo_Modificar);
            this.groupBox_ModificarTrabajos.Controls.Add(this.dateTimePicker_FechaDeIngreso_Modificar);
            this.groupBox_ModificarTrabajos.Controls.Add(this.btnModificar_Trabajo);
            this.groupBox_ModificarTrabajos.Controls.Add(this.dateTimePicker_Plazo_Modificar);
            this.groupBox_ModificarTrabajos.Controls.Add(this.txtAdelanto_Modificar);
            this.groupBox_ModificarTrabajos.Controls.Add(this.labelAdelanto_Modificar);
            this.groupBox_ModificarTrabajos.Controls.Add(this.labelFechaDeIngreso_Modificar);
            this.groupBox_ModificarTrabajos.Controls.Add(this.txtProblema_Modificar);
            this.groupBox_ModificarTrabajos.Controls.Add(this.labelProblema_Modificar);
            this.groupBox_ModificarTrabajos.Controls.Add(this.txtPresupuesto_Modificar);
            this.groupBox_ModificarTrabajos.Controls.Add(this.labelPresupuesto_Modificar);
            this.groupBox_ModificarTrabajos.Controls.Add(this.labelSeleccion_ID_Modificar);
            this.groupBox_ModificarTrabajos.Enabled = false;
            this.groupBox_ModificarTrabajos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_ModificarTrabajos.Location = new System.Drawing.Point(3, 3);
            this.groupBox_ModificarTrabajos.Name = "groupBox_ModificarTrabajos";
            this.groupBox_ModificarTrabajos.Size = new System.Drawing.Size(413, 0);
            this.groupBox_ModificarTrabajos.TabIndex = 8;
            this.groupBox_ModificarTrabajos.TabStop = false;
            this.groupBox_ModificarTrabajos.Text = "Modificar tabla trabajos";
            this.groupBox_ModificarTrabajos.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 13);
            this.label6.TabIndex = 37;
            this.label6.Text = "Celular:";
            // 
            // combobox_IDCelular_Modificar_Trabajo
            // 
            this.combobox_IDCelular_Modificar_Trabajo.FormattingEnabled = true;
            this.combobox_IDCelular_Modificar_Trabajo.Location = new System.Drawing.Point(3, 90);
            this.combobox_IDCelular_Modificar_Trabajo.Name = "combobox_IDCelular_Modificar_Trabajo";
            this.combobox_IDCelular_Modificar_Trabajo.Size = new System.Drawing.Size(401, 21);
            this.combobox_IDCelular_Modificar_Trabajo.TabIndex = 36;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 35;
            this.label4.Text = "Plazo:";
            // 
            // combobox_IDTecnico_Modificar_Trabajo
            // 
            this.combobox_IDTecnico_Modificar_Trabajo.FormattingEnabled = true;
            this.combobox_IDTecnico_Modificar_Trabajo.Location = new System.Drawing.Point(6, 429);
            this.combobox_IDTecnico_Modificar_Trabajo.Name = "combobox_IDTecnico_Modificar_Trabajo";
            this.combobox_IDTecnico_Modificar_Trabajo.Size = new System.Drawing.Size(401, 21);
            this.combobox_IDTecnico_Modificar_Trabajo.TabIndex = 34;
            this.combobox_IDTecnico_Modificar_Trabajo.Click += new System.EventHandler(this.combobox_IDTecnico_Modificar_Trabajo_Click);
            // 
            // labelID_Tecnico_Trabajo_Modificar
            // 
            this.labelID_Tecnico_Trabajo_Modificar.AutoSize = true;
            this.labelID_Tecnico_Trabajo_Modificar.Location = new System.Drawing.Point(3, 411);
            this.labelID_Tecnico_Trabajo_Modificar.Name = "labelID_Tecnico_Trabajo_Modificar";
            this.labelID_Tecnico_Trabajo_Modificar.Size = new System.Drawing.Size(129, 13);
            this.labelID_Tecnico_Trabajo_Modificar.TabIndex = 32;
            this.labelID_Tecnico_Trabajo_Modificar.Text = "Tecnico responsable:";
            // 
            // dateTimePicker_FechaDeIngreso_Modificar
            // 
            this.dateTimePicker_FechaDeIngreso_Modificar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dateTimePicker_FechaDeIngreso_Modificar.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker_FechaDeIngreso_Modificar.Location = new System.Drawing.Point(6, 325);
            this.dateTimePicker_FechaDeIngreso_Modificar.Name = "dateTimePicker_FechaDeIngreso_Modificar";
            this.dateTimePicker_FechaDeIngreso_Modificar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dateTimePicker_FechaDeIngreso_Modificar.Size = new System.Drawing.Size(401, 20);
            this.dateTimePicker_FechaDeIngreso_Modificar.TabIndex = 22;
            this.dateTimePicker_FechaDeIngreso_Modificar.Value = new System.DateTime(2023, 10, 24, 0, 0, 0, 0);
            // 
            // btnModificar_Trabajo
            // 
            this.btnModificar_Trabajo.Location = new System.Drawing.Point(312, 478);
            this.btnModificar_Trabajo.Name = "btnModificar_Trabajo";
            this.btnModificar_Trabajo.Size = new System.Drawing.Size(92, 30);
            this.btnModificar_Trabajo.TabIndex = 24;
            this.btnModificar_Trabajo.Text = "Modificar";
            this.btnModificar_Trabajo.UseVisualStyleBackColor = true;
            this.btnModificar_Trabajo.Click += new System.EventHandler(this.btnModificar_Trabajo_Click);
            // 
            // dateTimePicker_Plazo_Modificar
            // 
            this.dateTimePicker_Plazo_Modificar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dateTimePicker_Plazo_Modificar.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker_Plazo_Modificar.Location = new System.Drawing.Point(3, 141);
            this.dateTimePicker_Plazo_Modificar.Name = "dateTimePicker_Plazo_Modificar";
            this.dateTimePicker_Plazo_Modificar.Size = new System.Drawing.Size(401, 20);
            this.dateTimePicker_Plazo_Modificar.TabIndex = 21;
            this.dateTimePicker_Plazo_Modificar.Value = new System.DateTime(2023, 10, 24, 0, 0, 0, 0);
            // 
            // txtAdelanto_Modificar
            // 
            this.txtAdelanto_Modificar.Location = new System.Drawing.Point(6, 376);
            this.txtAdelanto_Modificar.Name = "txtAdelanto_Modificar";
            this.txtAdelanto_Modificar.Size = new System.Drawing.Size(401, 20);
            this.txtAdelanto_Modificar.TabIndex = 23;
            // 
            // labelAdelanto_Modificar
            // 
            this.labelAdelanto_Modificar.AutoSize = true;
            this.labelAdelanto_Modificar.Location = new System.Drawing.Point(3, 360);
            this.labelAdelanto_Modificar.Name = "labelAdelanto_Modificar";
            this.labelAdelanto_Modificar.Size = new System.Drawing.Size(96, 13);
            this.labelAdelanto_Modificar.TabIndex = 22;
            this.labelAdelanto_Modificar.Text = "Adelanto/Seña:";
            // 
            // labelFechaDeIngreso_Modificar
            // 
            this.labelFechaDeIngreso_Modificar.AutoSize = true;
            this.labelFechaDeIngreso_Modificar.Location = new System.Drawing.Point(3, 309);
            this.labelFechaDeIngreso_Modificar.Name = "labelFechaDeIngreso_Modificar";
            this.labelFechaDeIngreso_Modificar.Size = new System.Drawing.Size(109, 13);
            this.labelFechaDeIngreso_Modificar.TabIndex = 20;
            this.labelFechaDeIngreso_Modificar.Text = "Fecha de ingreso:";
            // 
            // txtProblema_Modificar
            // 
            this.txtProblema_Modificar.Location = new System.Drawing.Point(5, 241);
            this.txtProblema_Modificar.Multiline = true;
            this.txtProblema_Modificar.Name = "txtProblema_Modificar";
            this.txtProblema_Modificar.Size = new System.Drawing.Size(401, 53);
            this.txtProblema_Modificar.TabIndex = 19;
            // 
            // labelProblema_Modificar
            // 
            this.labelProblema_Modificar.AutoSize = true;
            this.labelProblema_Modificar.Location = new System.Drawing.Point(2, 225);
            this.labelProblema_Modificar.Name = "labelProblema_Modificar";
            this.labelProblema_Modificar.Size = new System.Drawing.Size(63, 13);
            this.labelProblema_Modificar.TabIndex = 18;
            this.labelProblema_Modificar.Text = "Problema:";
            // 
            // txtPresupuesto_Modificar
            // 
            this.txtPresupuesto_Modificar.Location = new System.Drawing.Point(4, 192);
            this.txtPresupuesto_Modificar.Name = "txtPresupuesto_Modificar";
            this.txtPresupuesto_Modificar.Size = new System.Drawing.Size(401, 20);
            this.txtPresupuesto_Modificar.TabIndex = 17;
            // 
            // labelPresupuesto_Modificar
            // 
            this.labelPresupuesto_Modificar.AutoSize = true;
            this.labelPresupuesto_Modificar.Location = new System.Drawing.Point(1, 176);
            this.labelPresupuesto_Modificar.Name = "labelPresupuesto_Modificar";
            this.labelPresupuesto_Modificar.Size = new System.Drawing.Size(81, 13);
            this.labelPresupuesto_Modificar.TabIndex = 16;
            this.labelPresupuesto_Modificar.Text = "Presupuesto:";
            // 
            // labelSeleccion_ID_Modificar
            // 
            this.labelSeleccion_ID_Modificar.AutoSize = true;
            this.labelSeleccion_ID_Modificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSeleccion_ID_Modificar.Location = new System.Drawing.Point(3, 37);
            this.labelSeleccion_ID_Modificar.Name = "labelSeleccion_ID_Modificar";
            this.labelSeleccion_ID_Modificar.Size = new System.Drawing.Size(67, 13);
            this.labelSeleccion_ID_Modificar.TabIndex = 12;
            this.labelSeleccion_ID_Modificar.Text = "Selección:";
            // 
            // groupBox_ModificarCelulares
            // 
            this.groupBox_ModificarCelulares.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox_ModificarCelulares.Controls.Add(this.groupBox_ModificarCelular_Estados);
            this.groupBox_ModificarCelulares.Controls.Add(this.txt_PresupuestoModificar);
            this.groupBox_ModificarCelulares.Controls.Add(this.label22);
            this.groupBox_ModificarCelulares.Controls.Add(this.label12);
            this.groupBox_ModificarCelulares.Controls.Add(this.dtp_ModificarCelular_Plazo);
            this.groupBox_ModificarCelulares.Controls.Add(this.label25);
            this.groupBox_ModificarCelulares.Controls.Add(this.txt_AdelantoModificar);
            this.groupBox_ModificarCelulares.Controls.Add(this.label23);
            this.groupBox_ModificarCelulares.Controls.Add(this.comboBox_ModificarTecnicoACargo);
            this.groupBox_ModificarCelulares.Controls.Add(this.txtIMEI_Modificar);
            this.groupBox_ModificarCelulares.Controls.Add(this.label19);
            this.groupBox_ModificarCelulares.Controls.Add(this.label18);
            this.groupBox_ModificarCelulares.Controls.Add(this.btn_ModificarTecnicoACargo_Buscar);
            this.groupBox_ModificarCelulares.Controls.Add(this.btn_ModificarClientes_Buscar);
            this.groupBox_ModificarCelulares.Controls.Add(this.dtp_ModificarIngresoCelulares);
            this.groupBox_ModificarCelulares.Controls.Add(this.combobox_CI_Del_Dueño_Modificar);
            this.groupBox_ModificarCelulares.Controls.Add(this.label_modificarCelular_Seleccion);
            this.groupBox_ModificarCelulares.Controls.Add(this.btnModificar_Celular);
            this.groupBox_ModificarCelulares.Controls.Add(this.labelID_Dueño_Modificar);
            this.groupBox_ModificarCelulares.Controls.Add(this.labelTecnico_A_Cargo_Modificar);
            this.groupBox_ModificarCelulares.Controls.Add(this.labelIMEI_Modificar);
            this.groupBox_ModificarCelulares.Controls.Add(this.txtModelo_Modificar);
            this.groupBox_ModificarCelulares.Controls.Add(this.labelMarca_Modificar);
            this.groupBox_ModificarCelulares.Controls.Add(this.label24);
            this.groupBox_ModificarCelulares.Controls.Add(this.label9);
            this.groupBox_ModificarCelulares.Controls.Add(this.label17);
            this.groupBox_ModificarCelulares.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_ModificarCelulares.Location = new System.Drawing.Point(3, 3);
            this.groupBox_ModificarCelulares.Name = "groupBox_ModificarCelulares";
            this.groupBox_ModificarCelulares.Size = new System.Drawing.Size(413, 594);
            this.groupBox_ModificarCelulares.TabIndex = 7;
            this.groupBox_ModificarCelulares.TabStop = false;
            this.groupBox_ModificarCelulares.Text = "Modificar Celular";
            // 
            // groupBox_ModificarCelular_Estados
            // 
            this.groupBox_ModificarCelular_Estados.AutoSize = true;
            this.groupBox_ModificarCelular_Estados.Controls.Add(this.label_caracteresRestantes_Detalles_Modificar);
            this.groupBox_ModificarCelular_Estados.Controls.Add(this.label2);
            this.groupBox_ModificarCelular_Estados.Controls.Add(this.txtDetallesUobservaciones_Modificar);
            this.groupBox_ModificarCelular_Estados.Controls.Add(this.radioButton_Arreglado_Modificar);
            this.groupBox_ModificarCelular_Estados.Controls.Add(this.radioButton_EnProceso_Modificar);
            this.groupBox_ModificarCelular_Estados.Controls.Add(this.radioButton_EnEspera_Modificar);
            this.groupBox_ModificarCelular_Estados.Controls.Add(this.radioButton_Averiado_Modificar);
            this.groupBox_ModificarCelular_Estados.Controls.Add(this.label20);
            this.groupBox_ModificarCelular_Estados.Location = new System.Drawing.Point(6, 355);
            this.groupBox_ModificarCelular_Estados.Name = "groupBox_ModificarCelular_Estados";
            this.groupBox_ModificarCelular_Estados.Size = new System.Drawing.Size(395, 197);
            this.groupBox_ModificarCelular_Estados.TabIndex = 36;
            this.groupBox_ModificarCelular_Estados.TabStop = false;
            this.groupBox_ModificarCelular_Estados.Text = "Estado del celular:";
            // 
            // label_caracteresRestantes_Detalles_Modificar
            // 
            this.label_caracteresRestantes_Detalles_Modificar.AutoSize = true;
            this.label_caracteresRestantes_Detalles_Modificar.Location = new System.Drawing.Point(317, 79);
            this.label_caracteresRestantes_Detalles_Modificar.Name = "label_caracteresRestantes_Detalles_Modificar";
            this.label_caracteresRestantes_Detalles_Modificar.Size = new System.Drawing.Size(72, 13);
            this.label_caracteresRestantes_Detalles_Modificar.TabIndex = 38;
            this.label_caracteresRestantes_Detalles_Modificar.Text = "65535/65535";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 13);
            this.label2.TabIndex = 37;
            this.label2.Text = "Detalles/Observaciones";
            // 
            // txtDetallesUobservaciones_Modificar
            // 
            this.txtDetallesUobservaciones_Modificar.Location = new System.Drawing.Point(7, 97);
            this.txtDetallesUobservaciones_Modificar.MaxLength = 0;
            this.txtDetallesUobservaciones_Modificar.Multiline = true;
            this.txtDetallesUobservaciones_Modificar.Name = "txtDetallesUobservaciones_Modificar";
            this.txtDetallesUobservaciones_Modificar.Size = new System.Drawing.Size(382, 81);
            this.txtDetallesUobservaciones_Modificar.TabIndex = 36;
            this.txtDetallesUobservaciones_Modificar.TextChanged += new System.EventHandler(this.txtDetallesUobservaciones_Modificar_TextChanged);
            this.txtDetallesUobservaciones_Modificar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDetallesUobservaciones_Modificar_KeyPress);
            // 
            // radioButton_Arreglado_Modificar
            // 
            this.radioButton_Arreglado_Modificar.AutoSize = true;
            this.radioButton_Arreglado_Modificar.BackColor = System.Drawing.Color.LightGreen;
            this.radioButton_Arreglado_Modificar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radioButton_Arreglado_Modificar.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_Arreglado_Modificar.ForeColor = System.Drawing.Color.Black;
            this.radioButton_Arreglado_Modificar.Location = new System.Drawing.Point(7, 20);
            this.radioButton_Arreglado_Modificar.Name = "radioButton_Arreglado_Modificar";
            this.radioButton_Arreglado_Modificar.Size = new System.Drawing.Size(80, 18);
            this.radioButton_Arreglado_Modificar.TabIndex = 27;
            this.radioButton_Arreglado_Modificar.TabStop = true;
            this.radioButton_Arreglado_Modificar.Text = "Arreglado";
            this.radioButton_Arreglado_Modificar.UseVisualStyleBackColor = false;
            // 
            // radioButton_EnProceso_Modificar
            // 
            this.radioButton_EnProceso_Modificar.AutoSize = true;
            this.radioButton_EnProceso_Modificar.BackColor = System.Drawing.Color.MidnightBlue;
            this.radioButton_EnProceso_Modificar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radioButton_EnProceso_Modificar.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_EnProceso_Modificar.ForeColor = System.Drawing.SystemColors.Control;
            this.radioButton_EnProceso_Modificar.Location = new System.Drawing.Point(6, 46);
            this.radioButton_EnProceso_Modificar.Name = "radioButton_EnProceso_Modificar";
            this.radioButton_EnProceso_Modificar.Size = new System.Drawing.Size(90, 18);
            this.radioButton_EnProceso_Modificar.TabIndex = 35;
            this.radioButton_EnProceso_Modificar.TabStop = true;
            this.radioButton_EnProceso_Modificar.Text = "En  proceso";
            this.radioButton_EnProceso_Modificar.UseVisualStyleBackColor = false;
            // 
            // radioButton_EnEspera_Modificar
            // 
            this.radioButton_EnEspera_Modificar.AutoSize = true;
            this.radioButton_EnEspera_Modificar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(221)))), ((int)(((byte)(51)))));
            this.radioButton_EnEspera_Modificar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radioButton_EnEspera_Modificar.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_EnEspera_Modificar.Location = new System.Drawing.Point(135, 48);
            this.radioButton_EnEspera_Modificar.Name = "radioButton_EnEspera_Modificar";
            this.radioButton_EnEspera_Modificar.Size = new System.Drawing.Size(80, 18);
            this.radioButton_EnEspera_Modificar.TabIndex = 34;
            this.radioButton_EnEspera_Modificar.TabStop = true;
            this.radioButton_EnEspera_Modificar.Text = "En espera";
            this.radioButton_EnEspera_Modificar.UseVisualStyleBackColor = false;
            // 
            // radioButton_Averiado_Modificar
            // 
            this.radioButton_Averiado_Modificar.AutoSize = true;
            this.radioButton_Averiado_Modificar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.radioButton_Averiado_Modificar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radioButton_Averiado_Modificar.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_Averiado_Modificar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.radioButton_Averiado_Modificar.Location = new System.Drawing.Point(135, 20);
            this.radioButton_Averiado_Modificar.Name = "radioButton_Averiado_Modificar";
            this.radioButton_Averiado_Modificar.Size = new System.Drawing.Size(74, 18);
            this.radioButton_Averiado_Modificar.TabIndex = 28;
            this.radioButton_Averiado_Modificar.TabStop = true;
            this.radioButton_Averiado_Modificar.Text = "Averiado";
            this.radioButton_Averiado_Modificar.UseVisualStyleBackColor = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Red;
            this.label20.Location = new System.Drawing.Point(104, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(12, 16);
            this.label20.TabIndex = 45;
            this.label20.Text = "*";
            // 
            // txt_PresupuestoModificar
            // 
            this.txt_PresupuestoModificar.ForeColor = System.Drawing.Color.Green;
            this.txt_PresupuestoModificar.Location = new System.Drawing.Point(6, 246);
            this.txt_PresupuestoModificar.Name = "txt_PresupuestoModificar";
            this.txt_PresupuestoModificar.Size = new System.Drawing.Size(401, 20);
            this.txt_PresupuestoModificar.TabIndex = 52;
            this.txt_PresupuestoModificar.Text = "$";
            this.txt_PresupuestoModificar.TextChanged += new System.EventHandler(this.txt_PresupuestoModificar_TextChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(3, 230);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(120, 13);
            this.label22.TabIndex = 53;
            this.label22.Text = "Presupuesto (Opcional):";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(5, 101);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(93, 13);
            this.label12.TabIndex = 38;
            this.label12.Text = "Fecha de Ingreso:";
            // 
            // dtp_ModificarCelular_Plazo
            // 
            this.dtp_ModificarCelular_Plazo.CustomFormat = "yyyy-MM-dd";
            this.dtp_ModificarCelular_Plazo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_ModificarCelular_Plazo.Location = new System.Drawing.Point(7, 202);
            this.dtp_ModificarCelular_Plazo.Name = "dtp_ModificarCelular_Plazo";
            this.dtp_ModificarCelular_Plazo.Size = new System.Drawing.Size(181, 20);
            this.dtp_ModificarCelular_Plazo.TabIndex = 49;
            this.dtp_ModificarCelular_Plazo.Value = new System.DateTime(2023, 11, 1, 0, 0, 0, 0);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(4, 187);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(36, 13);
            this.label25.TabIndex = 50;
            this.label25.Text = "Plazo:";
            // 
            // txt_AdelantoModificar
            // 
            this.txt_AdelantoModificar.ForeColor = System.Drawing.Color.Green;
            this.txt_AdelantoModificar.Location = new System.Drawing.Point(7, 157);
            this.txt_AdelantoModificar.Name = "txt_AdelantoModificar";
            this.txt_AdelantoModificar.Size = new System.Drawing.Size(400, 20);
            this.txt_AdelantoModificar.TabIndex = 46;
            this.txt_AdelantoModificar.Text = "$";
            this.txt_AdelantoModificar.TextChanged += new System.EventHandler(this.txt_AdelantoModificar_TextChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(7, 141);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(133, 13);
            this.label23.TabIndex = 47;
            this.label23.Text = "Adelanto/Seña (Opcional):";
            // 
            // comboBox_ModificarTecnicoACargo
            // 
            this.comboBox_ModificarTecnicoACargo.FormattingEnabled = true;
            this.comboBox_ModificarTecnicoACargo.Location = new System.Drawing.Point(7, 328);
            this.comboBox_ModificarTecnicoACargo.Name = "comboBox_ModificarTecnicoACargo";
            this.comboBox_ModificarTecnicoACargo.Size = new System.Drawing.Size(180, 21);
            this.comboBox_ModificarTecnicoACargo.TabIndex = 31;
            this.comboBox_ModificarTecnicoACargo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBox_ModificarTecnicoACargo_KeyPress);
            // 
            // txtIMEI_Modificar
            // 
            this.txtIMEI_Modificar.Location = new System.Drawing.Point(7, 288);
            this.txtIMEI_Modificar.Name = "txtIMEI_Modificar";
            this.txtIMEI_Modificar.Size = new System.Drawing.Size(400, 20);
            this.txtIMEI_Modificar.TabIndex = 5;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(91, 315);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(12, 16);
            this.label19.TabIndex = 44;
            this.label19.Text = "*";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Red;
            this.label18.Location = new System.Drawing.Point(97, 98);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(12, 16);
            this.label18.TabIndex = 43;
            this.label18.Text = "*";
            // 
            // btn_ModificarTecnicoACargo_Buscar
            // 
            this.btn_ModificarTecnicoACargo_Buscar.BackColor = System.Drawing.SystemColors.Control;
            this.btn_ModificarTecnicoACargo_Buscar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ModificarTecnicoACargo_Buscar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ModificarTecnicoACargo_Buscar.ForeColor = System.Drawing.SystemColors.Control;
            this.btn_ModificarTecnicoACargo_Buscar.Image = global::Diseño.Properties.Resources.lupa2;
            this.btn_ModificarTecnicoACargo_Buscar.Location = new System.Drawing.Point(193, 328);
            this.btn_ModificarTecnicoACargo_Buscar.Name = "btn_ModificarTecnicoACargo_Buscar";
            this.btn_ModificarTecnicoACargo_Buscar.Size = new System.Drawing.Size(26, 23);
            this.btn_ModificarTecnicoACargo_Buscar.TabIndex = 41;
            this.btn_ModificarTecnicoACargo_Buscar.UseVisualStyleBackColor = false;
            this.btn_ModificarTecnicoACargo_Buscar.Click += new System.EventHandler(this.btn_ModificarTecnicoACargo_Buscar_Click);
            // 
            // btn_ModificarClientes_Buscar
            // 
            this.btn_ModificarClientes_Buscar.BackColor = System.Drawing.SystemColors.Control;
            this.btn_ModificarClientes_Buscar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ModificarClientes_Buscar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ModificarClientes_Buscar.ForeColor = System.Drawing.SystemColors.Control;
            this.btn_ModificarClientes_Buscar.Image = global::Diseño.Properties.Resources.lupa2;
            this.btn_ModificarClientes_Buscar.Location = new System.Drawing.Point(192, 32);
            this.btn_ModificarClientes_Buscar.Name = "btn_ModificarClientes_Buscar";
            this.btn_ModificarClientes_Buscar.Size = new System.Drawing.Size(26, 23);
            this.btn_ModificarClientes_Buscar.TabIndex = 2;
            this.btn_ModificarClientes_Buscar.UseVisualStyleBackColor = false;
            this.btn_ModificarClientes_Buscar.Click += new System.EventHandler(this.btn_ModificarClientes_Buscar_Click);
            // 
            // dtp_ModificarIngresoCelulares
            // 
            this.dtp_ModificarIngresoCelulares.CustomFormat = "yyyy-MM-dd";
            this.dtp_ModificarIngresoCelulares.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_ModificarIngresoCelulares.Location = new System.Drawing.Point(7, 117);
            this.dtp_ModificarIngresoCelulares.Name = "dtp_ModificarIngresoCelulares";
            this.dtp_ModificarIngresoCelulares.Size = new System.Drawing.Size(181, 20);
            this.dtp_ModificarIngresoCelulares.TabIndex = 4;
            this.dtp_ModificarIngresoCelulares.Value = new System.DateTime(2023, 11, 1, 0, 0, 0, 0);
            // 
            // combobox_CI_Del_Dueño_Modificar
            // 
            this.combobox_CI_Del_Dueño_Modificar.AllowDrop = true;
            this.combobox_CI_Del_Dueño_Modificar.Cursor = System.Windows.Forms.Cursors.Default;
            this.combobox_CI_Del_Dueño_Modificar.FormattingEnabled = true;
            this.combobox_CI_Del_Dueño_Modificar.Location = new System.Drawing.Point(6, 32);
            this.combobox_CI_Del_Dueño_Modificar.Name = "combobox_CI_Del_Dueño_Modificar";
            this.combobox_CI_Del_Dueño_Modificar.Size = new System.Drawing.Size(180, 21);
            this.combobox_CI_Del_Dueño_Modificar.TabIndex = 1;
            this.combobox_CI_Del_Dueño_Modificar.KeyDown += new System.Windows.Forms.KeyEventHandler(this.combobox_CI_Del_Dueño_Modificar_KeyDown);
            this.combobox_CI_Del_Dueño_Modificar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.combobox_CI_Del_Dueño_Modificar_KeyPress);
            this.combobox_CI_Del_Dueño_Modificar.KeyUp += new System.Windows.Forms.KeyEventHandler(this.combobox_CI_Del_Dueño_Modificar_KeyUp);
            // 
            // label_modificarCelular_Seleccion
            // 
            this.label_modificarCelular_Seleccion.AutoSize = true;
            this.label_modificarCelular_Seleccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_modificarCelular_Seleccion.Location = new System.Drawing.Point(91, 0);
            this.label_modificarCelular_Seleccion.Name = "label_modificarCelular_Seleccion";
            this.label_modificarCelular_Seleccion.Size = new System.Drawing.Size(67, 13);
            this.label_modificarCelular_Seleccion.TabIndex = 30;
            this.label_modificarCelular_Seleccion.Text = "Selección:";
            // 
            // btnModificar_Celular
            // 
            this.btnModificar_Celular.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnModificar_Celular.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificar_Celular.Location = new System.Drawing.Point(306, 558);
            this.btnModificar_Celular.Name = "btnModificar_Celular";
            this.btnModificar_Celular.Size = new System.Drawing.Size(92, 30);
            this.btnModificar_Celular.TabIndex = 13;
            this.btnModificar_Celular.Text = "Modificar";
            this.btnModificar_Celular.UseVisualStyleBackColor = true;
            this.btnModificar_Celular.Click += new System.EventHandler(this.btnModificar_Celular_Click);
            // 
            // labelID_Dueño_Modificar
            // 
            this.labelID_Dueño_Modificar.AutoSize = true;
            this.labelID_Dueño_Modificar.Location = new System.Drawing.Point(4, 19);
            this.labelID_Dueño_Modificar.Name = "labelID_Dueño_Modificar";
            this.labelID_Dueño_Modificar.Size = new System.Drawing.Size(93, 13);
            this.labelID_Dueño_Modificar.TabIndex = 16;
            this.labelID_Dueño_Modificar.Text = "Dueño del celular:";
            // 
            // labelTecnico_A_Cargo_Modificar
            // 
            this.labelTecnico_A_Cargo_Modificar.AutoSize = true;
            this.labelTecnico_A_Cargo_Modificar.Location = new System.Drawing.Point(3, 315);
            this.labelTecnico_A_Cargo_Modificar.Name = "labelTecnico_A_Cargo_Modificar";
            this.labelTecnico_A_Cargo_Modificar.Size = new System.Drawing.Size(88, 13);
            this.labelTecnico_A_Cargo_Modificar.TabIndex = 25;
            this.labelTecnico_A_Cargo_Modificar.Text = "Técnico a cargo:";
            // 
            // labelIMEI_Modificar
            // 
            this.labelIMEI_Modificar.AutoSize = true;
            this.labelIMEI_Modificar.Location = new System.Drawing.Point(7, 272);
            this.labelIMEI_Modificar.Name = "labelIMEI_Modificar";
            this.labelIMEI_Modificar.Size = new System.Drawing.Size(83, 13);
            this.labelIMEI_Modificar.TabIndex = 18;
            this.labelIMEI_Modificar.Text = "IMEI (Opcional):";
            // 
            // txtModelo_Modificar
            // 
            this.txtModelo_Modificar.Location = new System.Drawing.Point(6, 74);
            this.txtModelo_Modificar.Name = "txtModelo_Modificar";
            this.txtModelo_Modificar.Size = new System.Drawing.Size(401, 20);
            this.txtModelo_Modificar.TabIndex = 3;
            // 
            // labelMarca_Modificar
            // 
            this.labelMarca_Modificar.AutoSize = true;
            this.labelMarca_Modificar.Location = new System.Drawing.Point(4, 61);
            this.labelMarca_Modificar.Name = "labelMarca_Modificar";
            this.labelMarca_Modificar.Size = new System.Drawing.Size(97, 13);
            this.labelMarca_Modificar.TabIndex = 22;
            this.labelMarca_Modificar.Text = "Marca y/o Modelo:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Red;
            this.label24.Location = new System.Drawing.Point(42, 185);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(12, 16);
            this.label24.TabIndex = 51;
            this.label24.Text = "*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(97, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(12, 16);
            this.label9.TabIndex = 37;
            this.label9.Text = "*";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(97, 59);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(12, 16);
            this.label17.TabIndex = 42;
            this.label17.Text = "*";
            // 
            // timer_GroupBox_ModificarT_Agrandar
            // 
            this.timer_GroupBox_ModificarT_Agrandar.Interval = 1;
            this.timer_GroupBox_ModificarT_Agrandar.Tick += new System.EventHandler(this.timer_GroupBox_ModificarT_Agrandar_Tick);
            // 
            // timer_GroupBox_ModificarT_Reducir
            // 
            this.timer_GroupBox_ModificarT_Reducir.Interval = 1;
            this.timer_GroupBox_ModificarT_Reducir.Tick += new System.EventHandler(this.timer_GroupBox_ModificarT_Reducir_Tick);
            // 
            // timer_Modificar_Agrandar
            // 
            this.timer_Modificar_Agrandar.Interval = 1;
            this.timer_Modificar_Agrandar.Tick += new System.EventHandler(this.timer_Modificar_Agrandar_Tick);
            // 
            // timer_Modificar_Reducir
            // 
            this.timer_Modificar_Reducir.Interval = 1;
            this.timer_Modificar_Reducir.Tick += new System.EventHandler(this.timer_Modificar_Reducir_Tick);
            // 
            // panel_Eliminar
            // 
            this.panel_Eliminar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel_Eliminar.Controls.Add(this.groupBox_EliminarTrabajos);
            this.panel_Eliminar.Controls.Add(this.groupBox_EliminarCelulares);
            this.panel_Eliminar.Enabled = false;
            this.panel_Eliminar.Location = new System.Drawing.Point(51, 105);
            this.panel_Eliminar.Name = "panel_Eliminar";
            this.panel_Eliminar.Size = new System.Drawing.Size(419, 0);
            this.panel_Eliminar.TabIndex = 18;
            // 
            // groupBox_EliminarTrabajos
            // 
            this.groupBox_EliminarTrabajos.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox_EliminarTrabajos.Controls.Add(this.txtID_Trabajo_Eliminar);
            this.groupBox_EliminarTrabajos.Controls.Add(this.btn_EliminarTrabajos);
            this.groupBox_EliminarTrabajos.Controls.Add(this.label5);
            this.groupBox_EliminarTrabajos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_EliminarTrabajos.Location = new System.Drawing.Point(3, 3);
            this.groupBox_EliminarTrabajos.Name = "groupBox_EliminarTrabajos";
            this.groupBox_EliminarTrabajos.Size = new System.Drawing.Size(413, 0);
            this.groupBox_EliminarTrabajos.TabIndex = 16;
            this.groupBox_EliminarTrabajos.TabStop = false;
            this.groupBox_EliminarTrabajos.Text = "Elimine un trabajo";
            // 
            // txtID_Trabajo_Eliminar
            // 
            this.txtID_Trabajo_Eliminar.AutoSize = true;
            this.txtID_Trabajo_Eliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtID_Trabajo_Eliminar.ForeColor = System.Drawing.Color.Brown;
            this.txtID_Trabajo_Eliminar.Location = new System.Drawing.Point(3, 62);
            this.txtID_Trabajo_Eliminar.Name = "txtID_Trabajo_Eliminar";
            this.txtID_Trabajo_Eliminar.Size = new System.Drawing.Size(207, 13);
            this.txtID_Trabajo_Eliminar.TabIndex = 15;
            this.txtID_Trabajo_Eliminar.Text = "Seleccione un elemento de la tabla";
            // 
            // btn_EliminarTrabajos
            // 
            this.btn_EliminarTrabajos.BackColor = System.Drawing.Color.Transparent;
            this.btn_EliminarTrabajos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_EliminarTrabajos.Image = ((System.Drawing.Image)(resources.GetObject("btn_EliminarTrabajos.Image")));
            this.btn_EliminarTrabajos.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_EliminarTrabajos.Location = new System.Drawing.Point(306, 114);
            this.btn_EliminarTrabajos.Name = "btn_EliminarTrabajos";
            this.btn_EliminarTrabajos.Size = new System.Drawing.Size(92, 30);
            this.btn_EliminarTrabajos.TabIndex = 14;
            this.btn_EliminarTrabajos.Text = "Dar de baja";
            this.btn_EliminarTrabajos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_EliminarTrabajos.UseVisualStyleBackColor = false;
            this.btn_EliminarTrabajos.Click += new System.EventHandler(this.btn_EliminarTrabajos_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 40);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(163, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "ID del celular que desea eliminar:";
            // 
            // groupBox_EliminarCelulares
            // 
            this.groupBox_EliminarCelulares.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox_EliminarCelulares.Controls.Add(this.labMostrarIDdelCelularSeleccionado);
            this.groupBox_EliminarCelulares.Controls.Add(this.btnEliminar_Celular);
            this.groupBox_EliminarCelulares.Controls.Add(this.label_ID_Celular_Eliminar);
            this.groupBox_EliminarCelulares.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_EliminarCelulares.Location = new System.Drawing.Point(3, 3);
            this.groupBox_EliminarCelulares.Name = "groupBox_EliminarCelulares";
            this.groupBox_EliminarCelulares.Size = new System.Drawing.Size(413, 0);
            this.groupBox_EliminarCelulares.TabIndex = 0;
            this.groupBox_EliminarCelulares.TabStop = false;
            this.groupBox_EliminarCelulares.Text = "Elimine un celular";
            // 
            // labMostrarIDdelCelularSeleccionado
            // 
            this.labMostrarIDdelCelularSeleccionado.AutoSize = true;
            this.labMostrarIDdelCelularSeleccionado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labMostrarIDdelCelularSeleccionado.ForeColor = System.Drawing.Color.Brown;
            this.labMostrarIDdelCelularSeleccionado.Location = new System.Drawing.Point(3, 62);
            this.labMostrarIDdelCelularSeleccionado.Name = "labMostrarIDdelCelularSeleccionado";
            this.labMostrarIDdelCelularSeleccionado.Size = new System.Drawing.Size(207, 13);
            this.labMostrarIDdelCelularSeleccionado.TabIndex = 15;
            this.labMostrarIDdelCelularSeleccionado.Text = "Seleccione un elemento de la tabla";
            // 
            // btnEliminar_Celular
            // 
            this.btnEliminar_Celular.BackColor = System.Drawing.Color.Transparent;
            this.btnEliminar_Celular.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEliminar_Celular.Image = ((System.Drawing.Image)(resources.GetObject("btnEliminar_Celular.Image")));
            this.btnEliminar_Celular.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEliminar_Celular.Location = new System.Drawing.Point(306, 114);
            this.btnEliminar_Celular.Name = "btnEliminar_Celular";
            this.btnEliminar_Celular.Size = new System.Drawing.Size(92, 30);
            this.btnEliminar_Celular.TabIndex = 14;
            this.btnEliminar_Celular.Text = "Dar de baja";
            this.btnEliminar_Celular.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEliminar_Celular.UseVisualStyleBackColor = false;
            this.btnEliminar_Celular.Click += new System.EventHandler(this.btnEliminar_Celular_Click);
            // 
            // label_ID_Celular_Eliminar
            // 
            this.label_ID_Celular_Eliminar.AutoSize = true;
            this.label_ID_Celular_Eliminar.Location = new System.Drawing.Point(3, 40);
            this.label_ID_Celular_Eliminar.Name = "label_ID_Celular_Eliminar";
            this.label_ID_Celular_Eliminar.Size = new System.Drawing.Size(163, 13);
            this.label_ID_Celular_Eliminar.TabIndex = 0;
            this.label_ID_Celular_Eliminar.Text = "ID del celular que desea eliminar:";
            // 
            // timer_GroupBox_EliminarC_Agrandar
            // 
            this.timer_GroupBox_EliminarC_Agrandar.Interval = 1;
            this.timer_GroupBox_EliminarC_Agrandar.Tick += new System.EventHandler(this.timer_GroupBox_EliminarC_Agrandar_Tick);
            // 
            // timer_GroupBox_EliminarC_Reducir
            // 
            this.timer_GroupBox_EliminarC_Reducir.Interval = 1;
            this.timer_GroupBox_EliminarC_Reducir.Tick += new System.EventHandler(this.timer_GroupBox_EliminarC_Reducir_Tick);
            // 
            // timer_GroupBox_EliminarT_Reducir
            // 
            this.timer_GroupBox_EliminarT_Reducir.Interval = 1;
            this.timer_GroupBox_EliminarT_Reducir.Tick += new System.EventHandler(this.timer_GroupBox_EliminarT_Reducir_Tick);
            // 
            // timer_GroupBox_EliminarT_Agrandar
            // 
            this.timer_GroupBox_EliminarT_Agrandar.Interval = 1;
            this.timer_GroupBox_EliminarT_Agrandar.Tick += new System.EventHandler(this.timer_GroupBox_EliminarT_Agrandar_Tick);
            // 
            // timer_Eliminar_Agrandar
            // 
            this.timer_Eliminar_Agrandar.Interval = 1;
            this.timer_Eliminar_Agrandar.Tick += new System.EventHandler(this.timer_Eliminar_Agrandar_Tick);
            // 
            // timer_Eliminar_Reducir
            // 
            this.timer_Eliminar_Reducir.Interval = 1;
            this.timer_Eliminar_Reducir.Tick += new System.EventHandler(this.timer_Eliminar_Reducir_Tick);
            // 
            // tablaCelulares
            // 
            this.tablaCelulares.AllowUserToAddRows = false;
            this.tablaCelulares.AllowUserToDeleteRows = false;
            this.tablaCelulares.AllowUserToResizeRows = false;
            this.tablaCelulares.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.tablaCelulares.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tablaCelulares.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.tablaCelulares.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.tablaCelulares.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tablaCelulares.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tablaCelulares.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.tablaCelulares.EnableHeadersVisualStyles = false;
            this.tablaCelulares.GridColor = System.Drawing.Color.DimGray;
            this.tablaCelulares.Location = new System.Drawing.Point(3, 3);
            this.tablaCelulares.MultiSelect = false;
            this.tablaCelulares.Name = "tablaCelulares";
            this.tablaCelulares.ReadOnly = true;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.WhiteSmoke;
            this.tablaCelulares.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.tablaCelulares.RowTemplate.ReadOnly = true;
            this.tablaCelulares.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.tablaCelulares.Size = new System.Drawing.Size(866, 595);
            this.tablaCelulares.TabIndex = 19;
            this.tablaCelulares.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.tablaCelulares_CellClick_1);
            this.tablaCelulares.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.tablaCelulares_CellFormatting);
            this.tablaCelulares.CellMouseEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.tablaCelulares_CellMouseEnter);
            this.tablaCelulares.CellMouseLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.tablaCelulares_CellMouseLeave);
            this.tablaCelulares.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.tablaCelulares_DataBindingComplete);
            this.tablaCelulares.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tablaCelulares_KeyDown);
            // 
            // tabIndex_Pestañas
            // 
            this.tabIndex_Pestañas.Controls.Add(this.tab_Celulares);
            this.tabIndex_Pestañas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabIndex_Pestañas.Location = new System.Drawing.Point(476, 100);
            this.tabIndex_Pestañas.Name = "tabIndex_Pestañas";
            this.tabIndex_Pestañas.SelectedIndex = 0;
            this.tabIndex_Pestañas.Size = new System.Drawing.Size(880, 627);
            this.tabIndex_Pestañas.TabIndex = 21;
            this.tabIndex_Pestañas.SelectedIndexChanged += new System.EventHandler(this.tabIndex_Pestañas_SelectedIndexChanged);
            this.tabIndex_Pestañas.TabIndexChanged += new System.EventHandler(this.tabIndex_Pestañas_TabIndexChanged);
            // 
            // tab_Celulares
            // 
            this.tab_Celulares.Controls.Add(this.tablaCelulares);
            this.tab_Celulares.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tab_Celulares.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tab_Celulares.Location = new System.Drawing.Point(4, 22);
            this.tab_Celulares.Name = "tab_Celulares";
            this.tab_Celulares.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Celulares.Size = new System.Drawing.Size(872, 601);
            this.tab_Celulares.TabIndex = 0;
            this.tab_Celulares.Text = "Celulares";
            this.tab_Celulares.UseVisualStyleBackColor = true;
            // 
            // timer_RecargarBDs
            // 
            this.timer_RecargarBDs.Interval = 1300;
            // 
            // timer_Transicion
            // 
            this.timer_Transicion.Enabled = true;
            this.timer_Transicion.Interval = 20;
            this.timer_Transicion.Tick += new System.EventHandler(this.timer_Transicion_Tick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1366, 25);
            this.panel1.TabIndex = 23;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(31, 6);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(174, 13);
            this.label21.TabIndex = 4;
            this.label21.Text = "Etech | Taller | Gestión de Celulares";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Diseño.Properties.Resources.logo_etech_uruguay_220_e1654881097513__1_;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(25, 25);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.button4.Cursor = System.Windows.Forms.Cursors.Default;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Image = global::Diseño.Properties.Resources.menos__1_;
            this.button4.Location = new System.Drawing.Point(1224, 0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(48, 25);
            this.button4.TabIndex = 2;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.button3.Cursor = System.Windows.Forms.Cursors.Default;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Image = global::Diseño.Properties.Resources.cuadricula;
            this.button3.Location = new System.Drawing.Point(1271, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(48, 25);
            this.button3.TabIndex = 1;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.button2.Cursor = System.Windows.Forms.Cursors.Default;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Image = global::Diseño.Properties.Resources.cruzado__1_;
            this.button2.Location = new System.Drawing.Point(1318, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(48, 25);
            this.button2.TabIndex = 0;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Enabled = false;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(173, 257);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(156, 75);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1366, 728);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tabIndex_Pestañas);
            this.Controls.Add(this.panelE);
            this.Controls.Add(this.panelD);
            this.Controls.Add(this.panel_Eliminar);
            this.Controls.Add(this.panel_Menu);
            this.Controls.Add(this.panel_Agregar);
            this.Controls.Add(this.panel_Modificar);
            this.Controls.Add(this.pictureBox1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Principal";
            this.Opacity = 0D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Etech | Taller";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Principal_FormClosed);
            this.Load += new System.EventHandler(this.Principal_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Principal_KeyUp);
            this.panelD.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnRecargar)).EndInit();
            this.panelE.ResumeLayout(false);
            this.panelE.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Taller)).EndInit();
            this.panel_Agregar.ResumeLayout(false);
            this.groupBox_AgregarCelulares.ResumeLayout(false);
            this.groupBox_AgregarCelulares.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel_Menu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_EtechLogo_PanelMenu)).EndInit();
            this.groupBox_Menu.ResumeLayout(false);
            this.panel_Modificar.ResumeLayout(false);
            this.groupBox_ModificarTrabajos.ResumeLayout(false);
            this.groupBox_ModificarTrabajos.PerformLayout();
            this.groupBox_ModificarCelulares.ResumeLayout(false);
            this.groupBox_ModificarCelulares.PerformLayout();
            this.groupBox_ModificarCelular_Estados.ResumeLayout(false);
            this.groupBox_ModificarCelular_Estados.PerformLayout();
            this.panel_Eliminar.ResumeLayout(false);
            this.groupBox_EliminarTrabajos.ResumeLayout(false);
            this.groupBox_EliminarTrabajos.PerformLayout();
            this.groupBox_EliminarCelulares.ResumeLayout(false);
            this.groupBox_EliminarCelulares.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tablaCelulares)).EndInit();
            this.tabIndex_Pestañas.ResumeLayout(false);
            this.tab_Celulares.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btnCerrarSesion;
        private System.Windows.Forms.Panel panelD;
        private System.Windows.Forms.Label label_Filtrar;
        private System.Windows.Forms.ComboBox MenuOpcionesCelular;
        private System.Windows.Forms.TextBox txtCampo_Busqueda;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Panel panelE;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Panel panel_Agregar;
        private System.Windows.Forms.Timer timer_Agregar_Agrandar;
        private System.Windows.Forms.GroupBox groupBox_AgregarCelulares;
        private System.Windows.Forms.Label labelID_Dueño_Agregar;
        private System.Windows.Forms.TextBox txtIMEI_Agregar;
        private System.Windows.Forms.Label labelIMEI_Agregar;
        private System.Windows.Forms.Button btnAgregar_Celular;
        private System.Windows.Forms.Label labelTecnico_A_Cargo_Agregar;
        private System.Windows.Forms.TextBox txtModeloYOmarca_Agregar;
        private System.Windows.Forms.Label labelModelo_Agregar;
        private System.Windows.Forms.Timer timer_GroupBox_AgregarC_Agrandar;
        private System.Windows.Forms.Timer timer_Agregar_Reducir;
        private System.Windows.Forms.Timer timer_GroupBox_AgregarC_Reducir;
        private System.Windows.Forms.Timer timer_GroupBox_AgregarT_Agrandar;
        private System.Windows.Forms.Timer timer_GroupBox_AgregarT_Reducir;
        private System.Windows.Forms.Button btnMenuPrincipal;
        private System.Windows.Forms.Panel panel_Menu;
        private System.Windows.Forms.GroupBox groupBox_Menu;
        private System.Windows.Forms.PictureBox pictureBox_EtechLogo_PanelMenu;
        private System.Windows.Forms.Button btnClientes;
        private System.Windows.Forms.Button btnEstadisticas;
        private System.Windows.Forms.Button btnUsuarios;
        private System.Windows.Forms.Timer timer_Menu_Agrandar;
        private System.Windows.Forms.Timer timer_Menu_Reducir;
        private System.Windows.Forms.Timer timer_GroupBox_Menu_Agrandar;
        private System.Windows.Forms.Timer timer_GroupBox_Menu_Reducir;
        private System.Windows.Forms.Timer timer_GroupBox_ModificarC_Reducir;
        private System.Windows.Forms.Timer timer_GroupBox_ModificarC_Agrandar;
        private System.Windows.Forms.Panel panel_Modificar;
        private System.Windows.Forms.GroupBox groupBox_ModificarCelulares;
        private System.Windows.Forms.Button btnModificar_Celular;
        private System.Windows.Forms.RadioButton radioButton_Averiado_Modificar;
        private System.Windows.Forms.RadioButton radioButton_Arreglado_Modificar;
        private System.Windows.Forms.Label labelTecnico_A_Cargo_Modificar;
        private System.Windows.Forms.Label labelMarca_Modificar;
        private System.Windows.Forms.TextBox txtModelo_Modificar;
        private System.Windows.Forms.TextBox txtIMEI_Modificar;
        private System.Windows.Forms.Label labelIMEI_Modificar;
        private System.Windows.Forms.Label labelID_Dueño_Modificar;
        private System.Windows.Forms.GroupBox groupBox_ModificarTrabajos;
        private System.Windows.Forms.Timer timer_GroupBox_ModificarT_Agrandar;
        private System.Windows.Forms.Timer timer_GroupBox_ModificarT_Reducir;
        private System.Windows.Forms.TextBox txtAdelanto_Modificar;
        private System.Windows.Forms.Label labelAdelanto_Modificar;
        private System.Windows.Forms.Label labelFechaDeIngreso_Modificar;
        private System.Windows.Forms.TextBox txtProblema_Modificar;
        private System.Windows.Forms.Label labelProblema_Modificar;
        private System.Windows.Forms.TextBox txtPresupuesto_Modificar;
        private System.Windows.Forms.Label labelPresupuesto_Modificar;
        private System.Windows.Forms.Label labelSeleccion_ID_Modificar;
        private System.Windows.Forms.Button btnModificar_Trabajo;
        private System.Windows.Forms.Timer timer_Modificar_Agrandar;
        private System.Windows.Forms.Timer timer_Modificar_Reducir;
        private System.Windows.Forms.Panel panel_Eliminar;
        private System.Windows.Forms.GroupBox groupBox_EliminarCelulares;
        private System.Windows.Forms.Button btnEliminar_Celular;
        private System.Windows.Forms.Label label_ID_Celular_Eliminar;
        private System.Windows.Forms.Timer timer_GroupBox_EliminarC_Agrandar;
        private System.Windows.Forms.Timer timer_GroupBox_EliminarC_Reducir;
        private System.Windows.Forms.Timer timer_GroupBox_EliminarT_Reducir;
        private System.Windows.Forms.Timer timer_GroupBox_EliminarT_Agrandar;
        private System.Windows.Forms.Timer timer_Eliminar_Agrandar;
        private System.Windows.Forms.Timer timer_Eliminar_Reducir;
        private System.Windows.Forms.DataGridView tablaCelulares;
        private System.Windows.Forms.Label label_Name_Form;
        private System.Windows.Forms.PictureBox pictureBox_Taller;
        private System.Windows.Forms.TextBox txtAdelanto_Agregar;
        private System.Windows.Forms.Label labelAdelanto_Agregar;
        private System.Windows.Forms.Label labelFechaDeIngreso_Agregar;
        private System.Windows.Forms.TextBox txtPresupuesto_Agregar;
        private System.Windows.Forms.Label labelPresupuesto_Agregar;
        private System.Windows.Forms.DateTimePicker dateTimePicker_FechaDeIngreso_Agregar;
        private System.Windows.Forms.PictureBox btnRecargar;
        private System.Windows.Forms.DateTimePicker dateTimePicker_FechaDeIngreso_Modificar;
        private System.Windows.Forms.DateTimePicker dateTimePicker_Plazo_Modificar;
        private System.Windows.Forms.Label labelID_Tecnico_Trabajo_Modificar;
        private System.Windows.Forms.Label labMostrarIDdelCelularSeleccionado;
        private System.Windows.Forms.TabControl tabIndex_Pestañas;
        private System.Windows.Forms.TabPage tab_Celulares;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_modificarCelular_Seleccion;
        private System.Windows.Forms.Timer timer_RecargarBDs;
        private System.Windows.Forms.ComboBox comboBox_ModificarTecnicoACargo;
        private System.Windows.Forms.ComboBox comboBox_AgregarCelular_IdDelTecnicoAcargo;
        private System.Windows.Forms.ComboBox comboBox_AgregarCelular_CedulaDelDueño;
        private System.Windows.Forms.ComboBox combobox_IDTecnico_Modificar_Trabajo;
        private System.Windows.Forms.ComboBox combobox_CI_Del_Dueño_Modificar;
        private System.Windows.Forms.GroupBox groupBox_ModificarCelular_Estados;
        private System.Windows.Forms.RadioButton radioButton_EnProceso_Modificar;
        private System.Windows.Forms.RadioButton radioButton_EnEspera_Modificar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDetallesUobservaciones_Modificar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDetallesUobservaciones_Agregar;
        private System.Windows.Forms.RadioButton radioButton_Arreglado_Agregar;
        private System.Windows.Forms.RadioButton radioButton_EnProceso_Agregar;
        private System.Windows.Forms.RadioButton radioButton_EnEspera_Agregar;
        private System.Windows.Forms.RadioButton radioButton_Averiado_Agregar;
        private System.Windows.Forms.Label label_CaracteresRestantes_Detalles_Agregar;
        private System.Windows.Forms.Label label_caracteresRestantes_Detalles_Modificar;
        private System.Windows.Forms.GroupBox groupBox_EliminarTrabajos;
        private System.Windows.Forms.Label txtID_Trabajo_Eliminar;
        private System.Windows.Forms.Button btn_EliminarTrabajos;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox combobox_IDCelular_Modificar_Trabajo;
        private System.Windows.Forms.DateTimePicker dateTimePicker_FechaPlazo_Agregar;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Timer timer_Transicion;
        private System.Windows.Forms.Button btn_BuscarClientesEnElComboboxDeAgregarCelulares;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn_ModificarTecnicoACargo_Buscar;
        private System.Windows.Forms.Button btn_ModificarClientes_Buscar;
        private System.Windows.Forms.DateTimePicker dtp_ModificarIngresoCelulares;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.DateTimePicker dtp_ModificarCelular_Plazo;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txt_AdelantoModificar;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txt_PresupuestoModificar;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label21;
    }
}

